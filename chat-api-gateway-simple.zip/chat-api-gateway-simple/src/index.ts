import { loadConfig } from "./config.js";
import { createApp } from "./app.js";
const config = loadConfig();
const { app } = createApp(config);
try {
  await app.listen({ port: config.port, host: config.host });
  console.log(`Gateway listening on ${config.host}:${config.port}`);
} catch {
  console.error("Unable to start gateway");
  process.exitCode = 1;
  await app.close();
}
for (const signal of ["SIGINT", "SIGTERM"] as const)
  process.once(signal, () => {
    void app.close();
  });
