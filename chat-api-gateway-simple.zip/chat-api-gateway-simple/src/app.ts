import Fastify from "fastify";
import { randomUUID } from "node:crypto";
import type { Config } from "./config.js";
import { openDatabase } from "./database.js";
import { matches } from "./auth.js";
import { ApiError, callUpstream } from "./upstream.js";
import { convert, validate } from "./openai.js";
import { enrich, saveCall, type RecordCall } from "./archive.js";
import { admin } from "./admin.js";
export function createApp(config: Config) {
  const app = Fastify({ logger: false, bodyLimit: 1024 * 1024 });
  const db = openDatabase(config.databasePath);
  const calls = new WeakMap<object, { start: number; record: RecordCall }>();
  app.addHook("onRequest", async (req) => {
    if (
      req.method === "POST" &&
      req.url.split("?")[0] === "/v1/chat/completions"
    )
      calls.set(req, {
        start: performance.now(),
        record: {
          id: randomUUID(),
          conversationId: null,
          model: config.model,
          status: 500,
          latency: 0,
          messages: [],
          error: null,
        },
      });
  });
  app.addHook("onSend", async (req, reply, payload) => {
    const call = calls.get(req);
    if (call) {
      calls.delete(req);
      call.record.status = reply.statusCode;
      call.record.latency = performance.now() - call.start;
      if (reply.statusCode >= 400 && !call.record.error)
        call.record.error = `Request failed (${reply.statusCode})`;
      saveCall(db, call.record);
    }
    return payload;
  });
  app.setErrorHandler((err, req, reply) => {
    const status =
      err instanceof ApiError
        ? err.status
        : err instanceof Error &&
            "statusCode" in err &&
            typeof err.statusCode === "number" &&
            err.statusCode < 500
          ? err.statusCode
          : 500;
    const message =
      err instanceof ApiError
        ? err.message
        : status < 500
          ? "Invalid request"
          : "Internal server error";
    const call = calls.get(req);
    if (call) call.record.error = message;
    reply
      .code(status)
      .send({
        error: {
          message,
          type: status < 500 ? "invalid_request_error" : "server_error",
        },
      });
  });
  app.get("/health", async () => ({ status: "ok" }));
  app.register(async (scope) => {
    scope.addHook("onRequest", async (req, reply) => {
      if (!matches(req.headers.authorization, `Bearer ${config.apiKey}`))
        return reply
          .code(401)
          .send({
            error: { message: "Invalid API key", type: "authentication_error" },
          });
    });
    scope.get("/v1/models", async () => ({
      object: "list",
      data: [
        {
          id: config.model,
          object: "model",
          created: 0,
          owned_by: "local-proxy",
        },
      ],
    }));
    scope.post("/v1/chat/completions", async (req, reply) => {
      const supplied = req.headers["x-conversation-id"];
      if (
        supplied !== undefined &&
        (typeof supplied !== "string" ||
          !/^[a-zA-Z0-9_-]{1,128}$/.test(supplied))
      )
        throw new ApiError(422, "Invalid X-Conversation-Id");
      const id = supplied ?? randomUUID();
      reply.header("X-Conversation-Id", id);
      const call = calls.get(req)!;
      call.record.conversationId = id;
      const { messages, stream } = validate(req.body, config.model);
      call.record.messages = messages;
      const upstream = convert(messages);
      enrich(db, id, messages, upstream);
      const output = await callUpstream(config, upstream);
      call.record.output = output;
      const base = {
        id: `chatcmpl-${call.record.id}`,
        created: Math.floor(Date.now() / 1000),
        model: config.model,
      };
      if (!stream)
        return {
          ...base,
          object: "chat.completion",
          choices: [
            {
              index: 0,
              message: { role: "assistant", content: output.content },
              finish_reason: "stop",
            },
          ],
        };
      const chunk = (delta: object, finish_reason: string | null) =>
        `data: ${JSON.stringify({ ...base, object: "chat.completion.chunk", choices: [{ index: 0, delta, finish_reason }] })}\n\n`;
      return reply
        .header("Content-Type", "text/event-stream; charset=utf-8")
        .header("Cache-Control", "no-cache")
        .send(
          chunk({ role: "assistant", content: output.content }, null) +
            chunk({}, "stop") +
            "data: [DONE]\n\n",
        );
    });
  });
  admin(app, db, config.adminKey);
  app.addHook("onClose", async () => {
    db.close();
  });
  return { app, db };
}
