import type { FastifyInstance } from "fastify";
import type { DB } from "./database.js";
import { matches } from "./auth.js";
import { ApiError } from "./upstream.js";
import { aggregates } from "./stats.js";
function integer(value: unknown, fallback: number, max: number) {
  if (value === undefined) return fallback;
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1 || n > max)
    throw new ApiError(422, `Expected integer between 1 and ${max}`);
  return n;
}
export function admin(app: FastifyInstance, db: DB, key: string) {
  app.register(async (scope) => {
    scope.addHook("onRequest", async (req, reply) => {
      if (!matches(req.headers["x-admin-key"], key))
        return reply
          .code(401)
          .send({
            error: {
              message: "Invalid admin key",
              type: "authentication_error",
            },
          });
    });
    scope.get("/admin/conversations", async (req) => {
      const q = req.query as Record<string, unknown>;
      const page = integer(q.page, 1, 1000000),
        limit = integer(q.limit, 20, 100);
      return {
        page,
        limit,
        total: (
          db.prepare("SELECT COUNT(*) AS n FROM conversations").get() as {
            n: number;
          }
        ).n,
        data: db
          .prepare(
            "SELECT * FROM conversations ORDER BY updated_at DESC LIMIT ? OFFSET ?",
          )
          .all(limit, (page - 1) * limit),
      };
    });
    const detail = (id: string) => {
      const conversation = db
        .prepare("SELECT * FROM conversations WHERE id=?")
        .get(id);
      if (!conversation) throw new ApiError(404, "Conversation not found");
      return {
        conversation,
        messages: db
          .prepare(
            "SELECT id,conversation_id,request_id,role,content,upstream_message_id,created_at FROM messages WHERE conversation_id=? ORDER BY rowid",
          )
          .all(id),
        requests: db
          .prepare(
            "SELECT id,status,http_status,archive_mode,created_at FROM requests WHERE conversation_id=? ORDER BY rowid",
          )
          .all(id),
      };
    };
    scope.get<{ Params: { id: string } }>(
      "/admin/conversations/:id",
      async (req) => detail(req.params.id),
    );
    scope.get<{ Params: { id: string } }>(
      "/admin/conversations/:id/export",
      async (req, reply) =>
        reply
          .header(
            "Content-Disposition",
            'attachment; filename="conversation.json"',
          )
          .send(detail(req.params.id)),
    );
    scope.get("/admin/stats", async () =>
      db.prepare(`SELECT ${aggregates} FROM requests`).get(),
    );
    scope.get("/admin/stats/daily", async (req) => {
      const days = integer(
        (req.query as Record<string, unknown>).days,
        30,
        366,
      );
      const start = new Date();
      start.setUTCHours(0, 0, 0, 0);
      start.setUTCDate(start.getUTCDate() - days + 1);
      return {
        timezone: "UTC",
        days,
        data: db
          .prepare(
            `SELECT substr(created_at,1,10) AS date, ${aggregates} FROM requests WHERE created_at>=? GROUP BY date ORDER BY date`,
          )
          .all(start.toISOString()),
      };
    });
  });
}
