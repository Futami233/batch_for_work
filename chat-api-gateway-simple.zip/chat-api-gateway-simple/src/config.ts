import "dotenv/config";
export interface Config {
  port: number;
  host: string;
  upstreamUrl: string;
  cookie: string;
  csrf: string;
  apiKey: string;
  adminKey: string;
  model: string;
  databasePath: string;
  timeout: number;
}
export function loadConfig(): Config {
  const required = (key: string) => {
    const value = process.env[key];
    if (!value) throw new Error(`Missing configuration: ${key}`);
    return value;
  };
  const integer = (key: string, fallback: number, max: number) => {
    const n = Number(process.env[key] ?? fallback);
    if (!Number.isInteger(n) || n < 1 || n > max)
      throw new Error(`Invalid configuration: ${key}`);
    return n;
  };
  const upstreamUrl = required("UPSTREAM_URL");
  if (!["http:", "https:"].includes(new URL(upstreamUrl).protocol))
    throw new Error("Invalid UPSTREAM_URL protocol");
  const apiKey = required("PROXY_API_KEY"),
    adminKey = required("ADMIN_API_KEY");
  if (apiKey === adminKey) throw new Error("API and admin keys must differ");
  return {
    port: integer("PORT", 3000, 65535),
    host: process.env.HOST ?? "127.0.0.1",
    upstreamUrl,
    cookie: required("UPSTREAM_COOKIE"),
    csrf: required("UPSTREAM_CSRF_TOKEN"),
    apiKey,
    adminKey,
    model: process.env.MODEL_NAME ?? "proxy-chat",
    databasePath: process.env.DATABASE_PATH ?? "./data/chat.db",
    timeout: integer("UPSTREAM_TIMEOUT_MS", 120000, 2147483647),
  };
}
