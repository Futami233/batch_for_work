import type { Config } from "./config.js";
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
export interface UpstreamMessage {
  role: string;
  content: string;
  fileList?: never[];
  imageList?: never[];
  messageId?: string;
  thoughtContent?: string;
}
export async function callUpstream(
  config: Config,
  messages: UpstreamMessage[],
) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.timeout);
  try {
    const response = await fetch(config.upstreamUrl, {
      method: "POST",
      redirect: "error",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Cookie: config.cookie,
        "X-Csrf-Token": config.csrf,
      },
      body: JSON.stringify(messages),
      signal: controller.signal,
    });
    if (!response.ok) throw new ApiError(502, "Upstream request failed");
    // The upstream is JSON-only. Never negotiate, parse, or retry with SSE.
    if (
      response.headers
        .get("content-type")
        ?.toLowerCase()
        .includes("text/event-stream")
    )
      throw new ApiError(502, "Expected a complete upstream JSON response");
    const body: unknown = await response.json();
    if (
      !body ||
      typeof body !== "object" ||
      !("respMessage" in body) ||
      typeof body.respMessage !== "string" ||
      !body.respMessage.trim()
    )
      throw new ApiError(502, "Invalid or empty upstream response");
    const obj = body as Record<string, unknown>;
    return {
      content: body.respMessage,
      messageId: typeof obj.messageId === "string" ? obj.messageId : null,
      thought:
        typeof obj.thoughtMessage === "string" ? obj.thoughtMessage : null,
    };
  } catch (error) {
    if (controller.signal.aborted)
      throw new ApiError(504, "Upstream request timed out");
    if (error instanceof ApiError) throw error;
    throw new ApiError(502, "Invalid upstream response or connection failure");
  } finally {
    clearTimeout(timer);
  }
}
