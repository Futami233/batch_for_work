import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
export function openDatabase(path: string) {
  if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec(
    "PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;",
  );
  db.exec(`CREATE TABLE IF NOT EXISTS conversations(id TEXT PRIMARY KEY,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,title TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY,conversation_id TEXT REFERENCES conversations(id),model TEXT,status TEXT NOT NULL,http_status INTEGER NOT NULL,latency_ms REAL NOT NULL,input_chars INTEGER NOT NULL,output_chars INTEGER NOT NULL,estimated_input_tokens INTEGER NOT NULL,estimated_output_tokens INTEGER NOT NULL,error_message TEXT,created_at TEXT NOT NULL,archive_mode TEXT NOT NULL,input_json TEXT,output_text TEXT,upstream_message_id TEXT,thought_content TEXT);
 CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,conversation_id TEXT NOT NULL REFERENCES conversations(id),request_id TEXT NOT NULL REFERENCES requests(id),role TEXT NOT NULL,content TEXT NOT NULL,upstream_message_id TEXT,thought_content TEXT,created_at TEXT NOT NULL);
 CREATE INDEX IF NOT EXISTS requests_conversation ON requests(conversation_id,created_at);
 CREATE INDEX IF NOT EXISTS requests_date ON requests(created_at);
 CREATE INDEX IF NOT EXISTS messages_conversation ON messages(conversation_id);`);
  return db;
}
export type DB = ReturnType<typeof openDatabase>;
