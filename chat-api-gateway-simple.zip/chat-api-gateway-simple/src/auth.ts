import { timingSafeEqual } from "node:crypto";
export function matches(actual: unknown, expected: string) {
  if (typeof actual !== "string") return false;
  const a = Buffer.from(actual),
    b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}
