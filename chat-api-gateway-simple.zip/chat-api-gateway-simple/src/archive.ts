import { randomUUID } from "node:crypto";
import type { DB } from "./database.js";
import type { Message } from "./openai.js";
import type { UpstreamMessage } from "./upstream.js";
type History = {
  input_json: string;
  output_text: string;
  upstream_message_id: string | null;
  thought_content: string | null;
};
const equal = (a: unknown, b: unknown) =>
  JSON.stringify(a) === JSON.stringify(b);
function history(db: DB, id: string) {
  return db
    .prepare(
      "SELECT input_json,output_text,upstream_message_id,thought_content FROM requests WHERE conversation_id=? AND status='success' ORDER BY rowid",
    )
    .all(id) as History[];
}
export function enrich(
  db: DB,
  id: string,
  messages: Message[],
  upstream: UpstreamMessage[],
) {
  const rows = history(db, id);
  let index = 0;
  messages.forEach((m, i) => {
    if (m.role === "system") return;
    const target = upstream[index++];
    if (m.role !== "assistant") return;
    const matches = rows.filter(
      (r) =>
        r.output_text === m.content &&
        equal(JSON.parse(r.input_json), messages.slice(0, i)),
    );
    const variants = new Set(
      matches.map((r) =>
        JSON.stringify([r.upstream_message_id, r.thought_content]),
      ),
    );
    if (matches.length && variants.size === 1) {
      const r = matches[0];
      if (r.upstream_message_id) target.messageId = r.upstream_message_id;
      if (r.thought_content) target.thoughtContent = r.thought_content;
    }
  });
}
export const chars = (text: string) => Array.from(text).length;
export const estimate = (n: number) => Math.ceil(n / 4);
export interface RecordCall {
  id: string;
  conversationId: string | null;
  model: string;
  status: number;
  latency: number;
  messages: Message[];
  error: string | null;
  output?: {
    content: string;
    messageId: string | null;
    thought: string | null;
  };
}
export function saveCall(db: DB, call: RecordCall) {
  db.exec("BEGIN IMMEDIATE");
  try {
    const { id, conversationId, messages, output } = call;
    const now = new Date().toISOString();
    let mode = "none";
    let added = messages;
    if (conversationId) {
      const rows = history(db, conversationId);
      let prefix = 0;
      for (const r of rows) {
        const previous = [
          ...JSON.parse(r.input_json),
          { role: "assistant", content: r.output_text },
        ];
        if (
          previous.length <= messages.length &&
          equal(previous, messages.slice(0, previous.length))
        )
          prefix = Math.max(prefix, previous.length);
      }
      mode = prefix ? "delta" : rows.length ? "snapshot" : "initial";
      added = messages.slice(prefix);
      db.prepare(
        "INSERT INTO conversations VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at",
      ).run(
        conversationId,
        now,
        now,
        (messages.find((m) => m.role === "user")?.content ?? "Request").slice(
          0,
          100,
        ),
      );
    }
    const input = messages.reduce((n, m) => n + chars(m.content), 0),
      out = chars(output?.content ?? "");
    db.prepare(
      "INSERT INTO requests VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
    ).run(
      id,
      conversationId,
      call.model,
      call.status < 400 ? "success" : "failed",
      call.status,
      call.latency,
      input,
      out,
      estimate(input),
      estimate(out),
      call.error,
      now,
      mode,
      messages.length ? JSON.stringify(messages) : null,
      output?.content ?? null,
      output?.messageId ?? null,
      output?.thought ?? null,
    );
    if (conversationId) {
      const insert = db.prepare(
        "INSERT INTO messages VALUES (?,?,?,?,?,?,?,?)",
      );
      for (const m of added)
        insert.run(
          randomUUID(),
          conversationId,
          id,
          m.role,
          m.content,
          null,
          null,
          now,
        );
      if (output)
        insert.run(
          randomUUID(),
          conversationId,
          id,
          "assistant",
          output.content,
          output.messageId,
          output.thought,
          now,
        );
    }
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}
