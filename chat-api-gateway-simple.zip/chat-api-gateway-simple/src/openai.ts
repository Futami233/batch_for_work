import { Readable } from "node:stream";
import { ApiError, type UpstreamMessage } from "./upstream.js";
export interface Message {
  role: "system" | "user" | "assistant";
  content: string;
}
export function validate(
  body: unknown,
  model: string,
): { messages: Message[]; stream: boolean } {
  if (!body || typeof body !== "object" || Array.isArray(body))
    throw new ApiError(422, "Expected a JSON object");
  const b = body as Record<string, unknown>;
  const allowed = new Set([
    "model",
    "messages",
    "stream",
    "temperature",
    "max_tokens",
    "max_completion_tokens",
    "top_p",
    "frequency_penalty",
    "presence_penalty",
    "seed",
    "user",
  ]);
  for (const k of Object.keys(b))
    if (!allowed.has(k)) throw new ApiError(422, `Unsupported parameter: ${k}`);
  if (b.model !== model) throw new ApiError(404, "Unknown model");
  if (b.stream !== undefined && typeof b.stream !== "boolean")
    throw new ApiError(422, "stream must be boolean");
  if (!Array.isArray(b.messages) || !b.messages.length)
    throw new ApiError(422, "messages must be a nonempty array");
  const messages = b.messages.map((m: unknown) => {
    if (!m || typeof m !== "object" || Array.isArray(m))
      throw new ApiError(422, "Invalid message");
    const o = m as Record<string, unknown>;
    if (
      Object.keys(o).some((k) => !["role", "content"].includes(k)) ||
      !["system", "user", "assistant"].includes(String(o.role)) ||
      typeof o.content !== "string"
    )
      throw new ApiError(
        422,
        "Only system/user/assistant plain text messages are supported",
      );
    return { role: o.role, content: o.content } as Message;
  });
  if (!messages.some((m) => m.role === "user"))
    throw new ApiError(422, "At least one user message is required");
  return { messages, stream: b.stream === true };
}
export function convert(messages: Message[]): UpstreamMessage[] {
  const system = messages
    .filter((m) => m.role === "system")
    .map((m) => m.content)
    .join("\n\n");
  let first = true;
  return messages
    .filter((m) => m.role !== "system")
    .map((m) => {
      if (m.role === "user") {
        const content =
          first && system
            ? `[SYSTEM CONTEXT]\n${system}\n[/SYSTEM CONTEXT]\n\n${m.content}`
            : m.content;
        first = false;
        return { role: m.role, content, fileList: [], imageList: [] };
      }
      return { role: m.role, content: m.content };
    });
}

export function completionStream(
  base: { id: string; created: number; model: string },
  content: string,
): Readable {
  const chunk = (delta: object, finish_reason: string | null = null) =>
    `data: ${JSON.stringify({ ...base, object: "chat.completion.chunk", choices: [{ index: 0, delta, finish_reason }] })}\n\n`;
  function* events() {
    yield chunk({ role: "assistant", content: "" });
    // Iterate code points so a chunk boundary never splits a surrogate pair.
    let part = "";
    let length = 0;
    for (const character of content) {
      part += character;
      if (++length === 128) {
        yield chunk({ content: part });
        part = "";
        length = 0;
      }
    }
    if (part) yield chunk({ content: part });
    yield chunk({}, "stop");
    yield "data: [DONE]\n\n";
  }
  return Readable.from(events(), { objectMode: false });
}
