# TASK_SIMPLE.md — Node.js 聊天 API 转 OpenAI 接口（简化版）

## 1. 目标

请使用 **Node.js + TypeScript** 开发一个可直接在本机或普通 Linux 服务器运行的 API 代理，将现有聊天 API 转换成 **OpenAI Chat Completions 兼容接口**，并提供两个附加功能：

1. **聊天存档**：把每次请求的用户提问、AI 回复及相关会话历史保存到 SQLite，方便检索。
2. **调用量统计**：记录每次 API 请求，查看每日调用次数、成功/失败次数、响应耗时、输入/输出字符数和估算 Token 数。

**不要实现** Claude Code、Anthropic Messages API、OpenAI Responses API、Docker、Kubernetes、复杂权限系统、工具调用、图片或文件上传。重点是功能少、代码清晰、容易维护。

要求 Codex **直接完成可运行代码、测试和 README**，不要仅输出设计方案。

## 2. 上游 API（根据截图）

通过环境变量设置真实接口地址、Cookie 和 CSRF Token。上游调用方式：

```http
POST ${UPSTREAM_URL}
Content-Type: application/json
Cookie: ${UPSTREAM_COOKIE}
X-Csrf-Token: ${UPSTREAM_CSRF_TOKEN}
```

注意：直接配置完整的 Cookie 字符串，不在代码里写死 Cookie 名称。**Cookie 和 CSRF 属于机密，禁止写入日志或 SQLite。**

上游请求体是**直接传递聊天历史 JSON 数组**，不是 `{ "messages": [...] }`：

```json
[
  { "role": "user", "content": "你好", "fileList": [], "imageList": [] },
  {
    "role": "assistant",
    "content": "你好，有什么可以帮你？",
    "messageId": "上一次AI回复的ID",
    "thoughtContent": "上一次AI回复的思考内容"
  },
  { "role": "user", "content": "继续回答", "fileList": [], "imageList": [] }
]
```

上游响应示例：

```json
{
  "fileSendMessages": [],
  "messageId": "上游消息ID",
  "requestTime": "",
  "respMessage": "AI回复内容",
  "response": "End",
  "thoughtMessage": "AI思考内容"
}
```

转换要求：

- `respMessage` → OpenAI 格式中的 `choices[0].message.content`。
- `messageId` → 归档保存；后续重放历史消息时带回上游。
- `thoughtMessage` → 可在本地归档，必要时作为后续历史里的 `thoughtContent` 回传上游；**不要将其暴露到 OpenAI 回复正文**。
- `fileList` / `imageList` → 目前仅支持空数组。
- 当前截图未证明支持原生 SSE、工具调用或多模态，**不要假装支持**。
- 用户未提供真实 API 凭据时，用 mock 上游测试，不声称真实上游已经验证。

## 3. 技术方案

尽量精简依赖：

- Node.js 22+，TypeScript。
- Fastify 提供 HTTP 服务。
- SQLite 保存数据（使用 `better-sqlite3` 或等效简单库）；首次启动自动建表。
- dotenv 加载环境变量。
- Vitest 编写基本测试。
- 不需要 Redis、消息队列、独立前端项目、Docker。

建议目录：

```text
src/
  index.ts            # 启动服务器
  config.ts           # 配置
  upstream.ts         # 上游请求及响应解析
  openai.ts           # OpenAI 格式转换和路由
  database.ts         # SQLite 初始化
  archive.ts          # 聊天存档
  stats.ts            # 调用统计
  admin.ts            # 查询存档与统计的简单接口
  auth.ts             # API Key 验证
 tests/
 .env.example
 package.json
 README.md
```

目录可适度调整，不要过度抽象。

## 4. 对外 API

### 4.1 `POST /v1/chat/completions`（必须）

采用常用 OpenAI 请求格式：

```json
{
  "model": "proxy-chat",
  "messages": [
    { "role": "user", "content": "你好" },
    { "role": "assistant", "content": "你好！" },
    { "role": "user", "content": "再说详细一点" }
  ],
  "stream": false
}
```

要求：

- 验证请求头 `Authorization: Bearer <API_KEY>`；本阶段仅需一个可在 `.env` 配置的 API Key。
- `model` 使用固定别名 `proxy-chat`，允许通过环境变量配置；未识别模型返回清晰错误。
- 支持 `system`、`user`、`assistant` 的**纯文本**消息。由于上游示例仅支持 user/assistant，将 system 文本以明确分隔符合并到第一条 user 消息，并在 README 说明它不具备原生 system 优先级。
- assistant 消息对应的历史 `messageId`、`thoughtContent`：若本地归档能确定性匹配之前的回复，则补充到上游请求；否则只发送 role/content，不伪造 ID。
- 每次调用依据客户端提供的 `messages` 生成**完整上游历史数组**；不得无条件叠加数据库中的历史导致重复内容。
- 返回符合 OpenAI Chat Completions 结构的 JSON，包含 `id`、`object: "chat.completion"`、`created`、`model`、`choices`、`finish_reason: "stop"`；不伪造精确 usage。
- 对不支持的 `tools`、图片、文件等格式直接返回 HTTP 422 和清晰错误。
- 对 `temperature`、`max_tokens` 等上游不支持的参数，在 README 中说明不生效，不假装已应用。
- 当上游报错、超时或响应无效时返回合理的 JSON 错误，不把 Cookie/CSRF 传给调用方。

#### 流式请求（简易兼容）

支持 `"stream": true`，返回 OpenAI Chat Completions SSE chunk，最后发送 `data: [DONE]`。**如果上游只有普通 JSON 响应，就等上游完整回复后再以 SSE 形式发出**；无需模拟逐字打字，必须在 README 标注“非原生实时流式”。

### 4.2 `GET /v1/models`（必须）

返回包含 `proxy-chat`（或配置的别名）的 OpenAI 风格模型列表。

### 4.3 `GET /health`（必须）

返回服务是否运行，不泄露密钥。

## 5. 聊天存档

使用 `data/chat.db`，自动创建数据库和目录。至少建立以下三张表（允许增加必要字段和索引）：

**conversations**：`id`、`created_at`、`updated_at`、`title`。

**messages**：`id`、`conversation_id`、`request_id`、`role`、`content`、`upstream_message_id`、`thought_content`、`created_at`。

**requests**：`id`、`conversation_id`、`model`、`status`、`http_status`、`latency_ms`、`input_chars`、`output_chars`、`estimated_input_tokens`、`estimated_output_tokens`、`error_message`、`created_at`。

具体要求：

- 每次 API 调用保存本轮用户输入和 AI 输出；失败调用至少保留请求元数据。
- 可以由客户端传 `X-Conversation-Id` 关联多轮对话；如不传则为本次请求生成新的会话 ID，并在响应头 `X-Conversation-Id` 返回。**不能凭空把来自不同请求的消息认定为同一会话。**
- 当客户端在一轮请求中携带完整历史时，只将本轮新增的消息归档，避免相同历史消息重复写入；若无法可靠区分，就按请求单独记录快照，明确标注而不错误合并。
- 保存上游 `messageId` 和 `thoughtMessage`，用于后续历史重建。默认不通过公共 API 暴露思考内容。
- 不保存任何 API Key 明文、上游 Cookie、CSRF 或 Authorization 头。
- 本地数据库禁止提交 Git（加入 `.gitignore`）。

提供简单管理接口：

- `GET /admin/conversations`：分页查看会话列表。
- `GET /admin/conversations/:id`：查看该会话消息记录。
- `GET /admin/conversations/:id/export`：导出 JSON。

`/admin/*` 使用独立的 `X-Admin-Key` 鉴权，不能使用普通 API Key 代替；无需登录网页或管理后台 UI。

## 6. 调用量统计

每次请求**只统计一次**，包括成功、失败、超时。数据从 `requests` 表聚合，无需单独统计数据库。

管理接口：

- `GET /admin/stats`：总请求数、成功数、失败数、平均响应耗时、估算输入和输出 Token 数。
- `GET /admin/stats/daily?days=30`：最近 N 天的每日调用统计（限制 N 的最大值）。

Token：截图中没有真实 Token 使用量。可使用一种简单且可解释的估算方法，并命名为 `estimated_*`；绝不把估算称为真实计费 Token。字符数必须单独统计。无需实现费用计算、价格配置或复杂图表。

## 7. 环境变量与本地运行

创建 `.env.example`：

```dotenv
PORT=3000
HOST=127.0.0.1
UPSTREAM_URL=https://example.com/chat-api
UPSTREAM_COOKIE=replace-with-full-cookie-string
UPSTREAM_CSRF_TOKEN=replace-with-csrf-token
PROXY_API_KEY=replace-with-client-key
ADMIN_API_KEY=replace-with-separate-admin-key
MODEL_NAME=proxy-chat
DATABASE_PATH=./data/chat.db
UPSTREAM_TIMEOUT_MS=120000
```

`.env` 必须加入 `.gitignore`。本地使用：

```bash
npm install
cp .env.example .env
# 编辑 .env 填入真实配置
npm run dev
```

同时提供 `npm run build`、`npm start`、`npm test`。README 给出 Linux 上直接使用 Node.js 运行的说明，无需 Docker。

## 8. README 使用示例

包含 curl 与官方 OpenAI Node.js SDK 示例，例如：

```ts
import OpenAI from 'openai';

const client = new OpenAI({
  apiKey: process.env.PROXY_API_KEY,
  baseURL: 'http://127.0.0.1:3000/v1'
});

const result = await client.chat.completions.create({
  model: 'proxy-chat',
  messages: [{ role: 'user', content: '你好' }]
});

console.log(result.choices[0]?.message?.content);
```

另需给出管理接口示例：使用 `X-Admin-Key` 获取最近 30 天统计和查询聊天存档。

## 9. 测试与验收

请创建 mock 上游，并至少测试：

1. 单轮及多轮聊天历史转换、`messageId` 回填逻辑。
2. OpenAI 非流式和 `stream=true` 的 SSE 格式。
3. 上游错误、超时、无效 JSON、空回复。
4. API Key / Admin Key 鉴权、工具及图片请求拒绝。
5. SQLite 保存聊天、会话隔离、重复历史防重、失败调用统计。
6. 每日调用数量聚合与 Token 估算字段。

**验收标准**：

- `npm install && npm test && npm run build` 均通过。
- `npm run dev` 能启动，`/health` 正常。
- 使用模拟上游，OpenAI SDK 可以完成单轮/多轮纯文本聊天；SSE 格式合法。
- 每次请求都可在 SQLite 找到存档或失败记录，管理接口能查询会话及每日统计。
- 真实上游未提供凭据时，明确标记为“尚未实测”，不得伪造测试结论。
- 项目中没有 Anthropic/Claude Code、Docker 或 Kubernetes 相关实现文件。

## 10. 交付物与实施顺序

交付：源码、`package.json`、`tsconfig.json`、`.env.example`、`.gitignore`、`README.md`、SQLite 初始化逻辑、mock 测试和自动化测试。

建议顺序：**启动工程 → 上游适配 → OpenAI 接口 → SQLite 存档 → 统计与管理接口 → 测试与 README**。

请直接开始实现。优先保证文本聊天稳定、存档可靠、统计准确；不增加本任务未要求的复杂功能。
