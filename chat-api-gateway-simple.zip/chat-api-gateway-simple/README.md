# Chat API Gateway

使用 Node.js 22.13+、TypeScript、Fastify 和 Node.js 内置 SQLite，将 JSON 聊天上游转换为 OpenAI Chat Completions 接口。包含聊天归档和调用统计，不需要独立前端。

## 运行

```bash
npm install
cp .env.example .env
# 编辑 .env，填写上游完整 URL、完整 Cookie、CSRF 及两个不同的密钥
npm run dev
```

默认监听 `127.0.0.1:3000`。首次启动自动创建 `data/chat.db` 和表。配置项见 `.env.example`；上游超时默认 120 秒。Node.js 必须为 22.13 或更高版本；部分版本会显示内置 SQLite 的实验特性提示，无需编译原生扩展。

Linux 生产运行：

```bash
npm ci
npm test
npm run build
npm start
```

在项目目录启动以加载 `.env`，可使用 systemd 管理 `npm start`。对外提供服务时自行配置 HTTPS 反向代理和 `HOST`。数据库含聊天正文与思考内容，应限制文件访问并定期备份；不要提交 `.env` 或数据库。服务不记录请求头、上游错误正文或凭据。密钥必须不同；管理接口仅接受独立管理密钥。

## 使用

```bash
curl http://127.0.0.1:3000/health
curl http://127.0.0.1:3000/v1/models -H "Authorization: Bearer $PROXY_API_KEY"
curl -i http://127.0.0.1:3000/v1/chat/completions \
  -H "Authorization: Bearer $PROXY_API_KEY" \
  -H 'Content-Type: application/json' \
  -H 'X-Conversation-Id: my-chat-1' \
  -d '{"model":"proxy-chat","messages":[{"role":"user","content":"你好"}],"stream":false}'
```

省略 `X-Conversation-Id` 会生成独立会话，响应头返回该 ID。后续调用传回 ID **及完整 messages 历史**；数据库不会自动拼接历史。ID 仅允许 1–128 位字母、数字、下划线和连字符。固定模型别名可通过 `MODEL_NAME` 修改。

官方 SDK 示例（调用方项目先运行 `npm install openai`）：

```ts
import OpenAI from "openai";
const client = new OpenAI({
  apiKey: process.env.PROXY_API_KEY,
  baseURL: "http://127.0.0.1:3000/v1",
  maxRetries: 0,
});
const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
  { role: "user", content: "你好" },
];
const { data: result, response } = await client.chat.completions
  .create({
    model: "proxy-chat",
    messages,
  })
  .withResponse();
console.log(result.choices[0]?.message?.content);
messages.push({
  role: "assistant",
  content: result.choices[0].message.content,
});
messages.push({ role: "user", content: "请详细解释" });
const stream = await client.chat.completions.create(
  {
    model: "proxy-chat",
    messages,
    stream: true,
  },
  {
    headers: {
      "X-Conversation-Id": response.headers.get("x-conversation-id")!,
    },
  },
);
for await (const chunk of stream) {
  process.stdout.write(chunk.choices[0]?.delta?.content ?? "");
}
```

上游已确认仅支持全量 JSON 返回。代理始终发送 `Accept: application/json` 和完整历史数组，不向上游传递 `stream`，不尝试连接、探测或回退到上游 SSE。若意外收到 SSE 响应，返回 502。

`stream:true` 仅在代理层兼容，是**非原生实时流式**：先等待上游完整 JSON，随后通过可读流依次发送角色 chunk、正文 chunk（每块最多 128 个 Unicode 码点）、stop chunk 和 `data: [DONE]`，不添加人工打字延迟。上游失败时仍返回普通 JSON 错误。未提供精确 usage，也不会将估算 Token 填入 OpenAI usage。

## 兼容范围

只接受 `system`、`user`、`assistant` 的字符串内容。所有 system 内容按顺序合并，用 `[SYSTEM CONTEXT]` 和 `[/SYSTEM CONTEXT]` 分隔后放到第一条 user 内容前；**不具备原生 system 优先级**。user 消息发送空 `fileList` / `imageList`，上游请求体直接为数组。

`temperature`、`max_tokens`、`max_completion_tokens`、`top_p`、`frequency_penalty`、`presence_penalty`、`seed`、`user` 接受但不生效，不传上游。其他参数（包括 tools、tool_choice、response_format、stream_options）及图片、文件、数组内容返回 422。未知模型返回 404，鉴权失败 401，上游错误或无效/空响应 502，超时 504。JSON 语法错误返回 400，请求体上限 1 MiB。

## 存档规则

每个 Chat Completions HTTP 调用只在 `requests` 中记一次，包含鉴权失败、校验失败、解析失败、超时及上游失败。健康检查、模型列表、管理查询不计入聊天调用量。无法识别会话的失败记录 `conversation_id` 为空；合法输入遇到上游失败仍保存输入和请求元数据。

每次合法请求保存完整输入快照到 `requests.input_json`。同一会话中，若输入以前一次成功调用的“完整输入 + AI 输出”为精确前缀，messages 只保存新增部分，`archive_mode=delta`。首次请求为 `initial`；分支、编辑或无法可靠匹配时为 `snapshot`，按 request_id 独立解释，不将其错误合并成线性历史。并发请求或重试也各自算一次 HTTP 调用，不实现幂等请求键。

只有同一会话、assistant 之前的完整原始历史与归档输入精确一致、回复正文一致，且候选元数据唯一时，才回填 `messageId` 和 `thoughtContent`。不同会话不会共享匹配；存在歧义则不回填。不伪造 ID。思考内容仅保存在本地数据库并用于上游重放，聊天响应、管理查询和 JSON 导出均不返回它。

## 管理接口

```bash
curl http://127.0.0.1:3000/admin/stats -H "X-Admin-Key: $ADMIN_API_KEY"
curl 'http://127.0.0.1:3000/admin/stats/daily?days=30' -H "X-Admin-Key: $ADMIN_API_KEY"
curl 'http://127.0.0.1:3000/admin/conversations?page=1&limit=20' -H "X-Admin-Key: $ADMIN_API_KEY"
curl http://127.0.0.1:3000/admin/conversations/my-chat-1 -H "X-Admin-Key: $ADMIN_API_KEY"
curl http://127.0.0.1:3000/admin/conversations/my-chat-1/export -H "X-Admin-Key: $ADMIN_API_KEY" -o conversation.json
```

分页 limit 最大 100。会话详情包含消息与请求的归档模式。每日统计按 UTC 分组，days 为 1–366，默认 30；仅返回有调用的日期。统计包含总数、成功/失败、平均耗时、输入/输出字符数和 `estimated_input_tokens` / `estimated_output_tokens`。字符数按 Unicode 码点计算，包括客户端提交的完整历史；估算方法为每个请求 `ceil(字符数 / 4)` 再累加，**不是实际 Token 或计费数据**，中文等语言可能偏差很大。

## 验证与限制

```bash
npm test
npm run build
```

测试通过Fastify 注入 mock 上游与 fetch 传输适配验证历史转换、元数据回填、会话隔离、快照和去重、官方 OpenAI SDK 的单轮/多轮/SSE、鉴权、错误、超时、无效 JSON、空回复、SQLite 记录及每日统计。

真实上游尚未实测：未提供真实凭据。当前适配仅基于任务中的 JSON 响应示例，上游已由用户确认仅支持全量返回，禁止尝试上游 SSE。单个 API Key 的所有调用方共享信任域，会话 ID 不是权限边界；本项目不提供多用户权限系统。

当前受限执行环境中，`npm run dev` 的 IPC/端口监听被系统以 `EPERM` 拒绝，未完成真实监听端口的启动验收；`/health` 已通过 Fastify 请求注入验证。需在允许监听的本机或 Linux 环境执行上述启动命令。
