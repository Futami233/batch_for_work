import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import Fastify from "fastify";
import OpenAI from "openai";
import { createApp } from "../src/app.js";
import type { Config } from "../src/config.js";
let mock: ReturnType<typeof Fastify>,
  gateway: ReturnType<typeof createApp>,
  config: Config;
let captured: any[], mode: string;
const auth = { authorization: "Bearer client-secret" };
const admin = { "x-admin-key": "admin-secret" };
const user = { role: "user", content: "你好" };
const payload = (messages: any[] = [user], extra: object = {}) => ({
  model: "proxy-chat",
  messages,
  ...extra,
});
const chat = (
  messages: any[] = [user],
  headers: object = {},
  extra: object = {},
) =>
  gateway.app.inject({
    method: "POST",
    url: "/v1/chat/completions",
    headers: { ...auth, ...headers },
    payload: payload(messages, extra),
  });
beforeEach(async () => {
  captured = [];
  mode = "ok";
  mock = Fastify();
  mock.post("/", async (req, reply) => {
    captured.push(req.body);
    expect(req.headers.accept).toBe("application/json");
    expect(Array.isArray(req.body)).toBe(true);
    expect(req.body).not.toHaveProperty("stream");
    if (mode === "sse")
      return reply
        .type("text/event-stream")
        .send('data: {"respMessage":"answer"}\n\ndata: [DONE]\n\n');
    expect(req.headers.cookie).toBe("secret-cookie");
    expect(req.headers["x-csrf-token"]).toBe("secret-csrf");
    if (mode === "error")
      return reply.code(500).send("secret-cookie secret-csrf");
    if (mode === "json") return reply.type("application/json").send("{broken");
    if (mode === "empty") return { respMessage: "" };
    if (mode === "timeout") await new Promise((r) => setTimeout(r, 100));
    return {
      respMessage: mode === "long" ? "中".repeat(127) + "😀\n\"你好".repeat(80) : "answer",
      messageId: "upstream-id",
      thoughtMessage: "private thought",
    };
  });
  await mock.ready();
  vi.stubGlobal("fetch", async (_url: unknown, options: RequestInit) => {
    const request = mock
      .inject({
        method: "POST",
        url: "/",
        headers: options.headers as Record<string, string>,
        payload: options.body as string,
      })
      .then(
        (r) =>
          new Response(r.body, {
            status: r.statusCode,
            headers: r.headers as Record<string, string>,
          }),
      );
    return Promise.race([
      request,
      new Promise<Response>((_resolve, reject) => {
        options.signal?.addEventListener(
          "abort",
          () => reject(new Error("aborted")),
          { once: true },
        );
      }),
    ]);
  });
  config = {
    port: 3000,
    host: "127.0.0.1",
    upstreamUrl: "http://mock.local/",
    cookie: "secret-cookie",
    csrf: "secret-csrf",
    apiKey: "client-secret",
    adminKey: "admin-secret",
    model: "proxy-chat",
    databasePath: ":memory:",
    timeout: 1000,
  };
  gateway = createApp(config);
});
afterEach(async () => {
  await gateway?.app.close();
  await mock.close();
  vi.unstubAllGlobals();
});
describe("gateway", () => {
  it("translates system/history, fills metadata, deduplicates and isolates conversations", async () => {
    const messages = [{ role: "system", content: "be helpful" }, user];
    const first = await chat(messages);
    expect(first.statusCode).toBe(200);
    expect(first.json().choices[0].message.content).toBe("answer");
    expect(first.body).not.toContain("private thought");
    expect(first.json().usage).toBeUndefined();
    const id = first.headers["x-conversation-id"] as string;
    expect(captured[0]).toEqual([
      {
        role: "user",
        content: "[SYSTEM CONTEXT]\nbe helpful\n[/SYSTEM CONTEXT]\n\n你好",
        fileList: [],
        imageList: [],
      },
    ]);
    const next = [
      ...messages,
      { role: "assistant", content: "answer" },
      { role: "user", content: "continue" },
    ];
    await chat(next, { "x-conversation-id": id });
    expect(captured[1][1]).toEqual({
      role: "assistant",
      content: "answer",
      messageId: "upstream-id",
      thoughtContent: "private thought",
    });
    expect(captured[1]).toHaveLength(3);
    expect(
      (
        gateway.db
          .prepare("SELECT COUNT(*) AS n FROM messages WHERE conversation_id=?")
          .get(id) as any
      ).n,
    ).toBe(5);
    await chat(next);
    expect(captured[2][1]).toEqual({ role: "assistant", content: "answer" });
    await chat(
      [
        { role: "user", content: "different" },
        { role: "assistant", content: "answer" },
        user,
      ],
      { "x-conversation-id": id },
    );
    expect(captured[3][1].messageId).toBeUndefined();
    const detail = await gateway.app.inject({
      url: `/admin/conversations/${id}`,
      headers: admin,
    });
    expect(detail.json().requests.map((r: any) => r.archive_mode)).toEqual([
      "initial",
      "delta",
      "snapshot",
    ]);
    expect(detail.body).not.toContain("private thought");
    expect(
      (
        await gateway.app.inject({
          url: `/admin/conversations/${id}/export`,
          headers: admin,
        })
      ).statusCode,
    ).toBe(200);
  });
  it("supports official SDK JSON, multi-turn and SSE", async () => {
    const sdk = new OpenAI({
      apiKey: config.apiKey,
      baseURL: "http://gateway.local/v1",
      maxRetries: 0,
      fetch: async (input, options) => {
        const response = await gateway.app.inject({
          method: "POST",
          url: new URL(String(input)).pathname,
          headers: Object.fromEntries(new Headers(options?.headers)),
          payload: options?.body as string,
        });
        return new Response(response.body, {
          status: response.statusCode,
          headers: response.headers as Record<string, string>,
        });
      },
    });
    const { data, response } = await sdk.chat.completions
      .create({ model: "proxy-chat", messages: [user as any] })
      .withResponse();
    expect(data.choices[0].message.content).toBe("answer");
    const stream = await sdk.chat.completions.create(
      {
        model: "proxy-chat",
        messages: [
          user as any,
          { role: "assistant", content: "answer" },
          { role: "user", content: "next" },
        ],
        stream: true,
      },
      {
        headers: {
          "X-Conversation-Id": response.headers.get("x-conversation-id")!,
        },
      },
    );
    const chunks = [];
    for await (const c of stream) chunks.push(c);
    expect(chunks[0].choices[0].delta.role).toBe("assistant");
    expect(chunks.map((c) => c.choices[0].delta.content ?? "").join("")).toBe("answer");
    expect(chunks.at(-1)?.choices[0].finish_reason).toBe("stop");
    expect(captured[1][1].messageId).toBe("upstream-id");
    const raw = await chat([user], {}, { stream: true });
    expect(raw.headers["content-type"]).toContain("text/event-stream");
    expect(raw.body.endsWith("data: [DONE]\n\n")).toBe(true);
  });
  it.each(["error", "json", "empty", "timeout"])(
    "records sanitized %s failure exactly once",
    async (failure) => {
      mode = failure;
      if (failure === "timeout") config.timeout = 20;
      const r = await chat();
      expect(r.statusCode).toBe(failure === "timeout" ? 504 : 502);
      expect(r.body).not.toMatch(/secret-cookie|secret-csrf/);
      const rows = gateway.db.prepare("SELECT * FROM requests").all() as any[];
      expect(rows).toHaveLength(1);
      expect(rows[0].status).toBe("failed");
      expect(rows[0].input_chars).toBe(2);
      expect(JSON.stringify(rows)).not.toMatch(
        /secret-cookie|secret-csrf|client-secret/,
      );
    },
  );
  it("protects endpoints and rejects unsupported formats", async () => {
    expect((await gateway.app.inject({ url: "/health" })).statusCode).toBe(200);
    expect((await gateway.app.inject({ url: "/v1/models" })).statusCode).toBe(
      401,
    );
    expect(
      (await gateway.app.inject({ url: "/v1/models", headers: auth })).json()
        .data[0].id,
    ).toBe("proxy-chat");
    expect(
      (
        await gateway.app.inject({
          url: "/admin/stats",
          headers: { "x-admin-key": config.apiKey },
        })
      ).statusCode,
    ).toBe(401);
    expect(
      (
        await gateway.app.inject({
          method: "POST",
          url: "/v1/chat/completions",
          payload: payload(),
        })
      ).statusCode,
    ).toBe(401);
    expect((await chat([user], {}, { tools: [] })).statusCode).toBe(422);
    expect(
      (
        await chat([
          {
            role: "user",
            content: [{ type: "image_url", image_url: { url: "x" } }],
          },
        ])
      ).statusCode,
    ).toBe(422);
    expect((await chat([user], {}, { model: "unknown" })).statusCode).toBe(404);
    expect(
      (
        await gateway.app.inject({
          method: "POST",
          url: "/v1/chat/completions",
          headers: { ...auth, "content-type": "application/json" },
          payload: "{bad",
        })
      ).statusCode,
    ).toBe(400);
    expect(
      (gateway.db.prepare("SELECT COUNT(*) AS n FROM requests").get() as any).n,
    ).toBe(5);
    expect(captured).toHaveLength(0);
  });
  it("aggregates UTC daily counts, characters and estimates", async () => {
    await chat();
    mode = "error";
    await chat();
    const stats = (
      await gateway.app.inject({ url: "/admin/stats", headers: admin })
    ).json();
    expect(stats).toMatchObject({
      total_requests: 2,
      success_count: 1,
      failure_count: 1,
      input_chars: 4,
      output_chars: 6,
      estimated_input_tokens: 2,
      estimated_output_tokens: 2,
    });
    const daily = (
      await gateway.app.inject({
        url: "/admin/stats/daily?days=30",
        headers: admin,
      })
    ).json();
    expect(daily.data[0].total_requests).toBe(2);
    expect(daily.timezone).toBe("UTC");
    expect(
      (
        await gateway.app.inject({
          url: "/admin/stats/daily?days=367",
          headers: admin,
        })
      ).statusCode,
    ).toBe(422);
    expect(
      (
        await gateway.app.inject({
          url: "/admin/conversations?page=1&limit=1",
          headers: admin,
        })
      ).json().data,
    ).toHaveLength(1);
  });
});

it("persists archives and metadata across database reopen", async () => {
  const directory = mkdtempSync(join(tmpdir(), "gateway-test-"));
  await gateway.app.close();
  config.databasePath = join(directory, "nested", "chat.db");
  gateway = createApp(config);
  try {
    const first = await chat();
    const id = first.headers["x-conversation-id"] as string;
    await gateway.app.close();
    gateway = createApp(config);
    await chat(
      [
        user,
        { role: "assistant", content: "answer" },
        { role: "user", content: "next" },
      ],
      { "x-conversation-id": id },
    );
    expect(captured[1][1].messageId).toBe("upstream-id");
    expect(
      (gateway.db.prepare("SELECT COUNT(*) AS n FROM requests").get() as any).n,
    ).toBe(2);
    await gateway.app.close();
    gateway = createApp({ ...config, databasePath: ":memory:" });
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});
it("does not fill ambiguous historical metadata", async () => {
  const first = await chat();
  const id = first.headers["x-conversation-id"] as string;
  await chat([user], { "x-conversation-id": id });
  gateway.db
    .prepare(
      "UPDATE requests SET upstream_message_id='different-id' WHERE rowid=(SELECT MAX(rowid) FROM requests)",
    )
    .run();
  await chat(
    [
      user,
      { role: "assistant", content: "answer" },
      { role: "user", content: "next" },
    ],
    { "x-conversation-id": id },
  );
  expect(captured[2][1]).toEqual({ role: "assistant", content: "answer" });
});

it("rejects unexpected upstream SSE without retry for a streaming client", async () => {
  mode = "sse";
  const response = await chat([user], {}, { stream: true });
  expect(response.statusCode).toBe(502);
  expect(response.headers["content-type"]).toContain("application/json");
  expect(response.json().error.message).toBe(
    "Expected a complete upstream JSON response",
  );
  expect(captured).toHaveLength(1);
  expect(
    (gateway.db.prepare("SELECT COUNT(*) AS n FROM requests").get() as any).n,
  ).toBe(1);
});

it("streams complete Unicode content in bounded chunks and archives once", async () => {
  mode = "long";
  const response = await chat([user], {}, { stream: true });
  expect(response.statusCode).toBe(200);
  expect(response.headers["x-accel-buffering"]).toBe("no");
  expect(response.headers["content-length"]).toBeUndefined();
  const events = response.body.trim().split("\n\n");
  expect(events.pop()).toBe("data: [DONE]");
  const chunks = events.map((event) => JSON.parse(event.slice(6)));
  expect(chunks[0].choices[0].delta).toEqual({ role: "assistant", content: "" });
  expect(chunks.at(-1).choices[0]).toEqual({ index: 0, delta: {}, finish_reason: "stop" });
  const parts = chunks.slice(1, -1).map((c) => c.choices[0].delta.content);
  expect(parts.length).toBeGreaterThan(1);
  expect(parts.every((part) => Array.from(part).length <= 128)).toBe(true);
  expect(parts.join("")).toBe("中".repeat(127) + "😀\n\"你好".repeat(80));
  expect(new Set(chunks.map((c) => c.id)).size).toBe(1);
  expect(response.body).not.toContain("private thought");
  expect((gateway.db.prepare("SELECT COUNT(*) AS n FROM requests").get() as any).n).toBe(1);
});
