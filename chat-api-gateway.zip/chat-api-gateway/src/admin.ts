import type { FastifyInstance } from "fastify";
import { randomUUID, randomBytes } from "node:crypto";
import { readFileSync } from "node:fs";
import { z } from "zod";
import type { Config } from "./config.js";
import { Store, hash } from "./db.js";
import { ApiError } from "./lib/errors.js";
const query = z
  .object({
    limit: z.coerce.number().int().min(1).max(100).default(50),
    offset: z.coerce.number().int().min(0).max(100000).default(0),
    from: z.string().optional(),
    to: z.string().optional(),
    model: z.string().max(200).optional(),
    q: z.string().min(1).max(200).optional(),
    client: z.enum(["chat", "responses", "anthropic"]).optional(),
    granularity: z.enum(["hour", "day"]).default("day"),
  })
  .strict();
function filters(raw: unknown) {
  const r = query.safeParse(raw);
  if (!r.success)
    throw new ApiError(
      400,
      "invalid_request_error",
      "Invalid pagination or filters",
    );
  const q = r.data;
  const to = q.to ? Date.parse(q.to) : Date.now();
  const from = q.from ? Date.parse(q.from) : to - 30 * 86400000;
  if (
    !Number.isFinite(from) ||
    !Number.isFinite(to) ||
    from > to ||
    to - from > 366 * 86400000
  )
    throw new ApiError(
      400,
      "invalid_request_error",
      "Time range must be valid and at most 366 days",
    );
  return { ...q, from, to };
}
export function adminRoutes(
  app: FastifyInstance,
  db: Store,
  c: Config,
  inflight: () => number,
) {
  app.get("/admin", async (_r, reply) =>
    reply
      .type("text/html")
      .header(
        "content-security-policy",
        "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'",
      )
      .send(
        readFileSync(new URL("../public/admin.html", import.meta.url), "utf8"),
      ),
  );
  app.get("/admin.js", async (_r, reply) =>
    reply
      .type("application/javascript")
      .send(
        readFileSync(new URL("../public/admin.js", import.meta.url), "utf8"),
      ),
  );
  app.get("/admin.css", async (_r, reply) =>
    reply
      .type("text/css")
      .send(
        readFileSync(new URL("../public/admin.css", import.meta.url), "utf8"),
      ),
  );
  function checkSearch(q: ReturnType<typeof filters>) {
    if (q.q && c.ARCHIVE_ENCRYPTION_KEY)
      throw new ApiError(
        422,
        "unsupported_feature",
        "Search encrypted archives by metadata or export to search locally",
      );
  }
  app.get("/admin/requests", async (req) => {
    const q = filters(req.query);
    checkSearch(q);
    return {
      data: db
        .all(
          "SELECT * FROM requests WHERE started_at BETWEEN ? AND ? AND (? IS NULL OR instr(external_request_json,?)>0 OR instr(upstream_response_json,?)>0) ORDER BY started_at DESC LIMIT ? OFFSET ?",
          q.from,
          q.to,
          q.q ?? null,
          q.q ?? null,
          q.q ?? null,
          q.limit,
          q.offset,
        )
        .map((r) => ({
          ...r,
          external_request_json: db.decode(r.external_request_json),
          upstream_request_json: db.decode(r.upstream_request_json),
          upstream_response_json: db.decode(r.upstream_response_json),
        })),
    };
  });
  app.get("/admin/keys", async (req) => {
    const q = filters(req.query);
    return {
      data: db.all(
        "SELECT id,name,status,created_at,last_used_at FROM api_keys ORDER BY created_at DESC LIMIT ? OFFSET ?",
        q.limit,
        q.offset,
      ),
    };
  });
  app.post("/admin/keys", async (req, reply) => {
    const b = z
      .object({ name: z.string().min(1).max(100) })
      .strict()
      .safeParse(req.body);
    if (!b.success)
      throw new ApiError(
        400,
        "invalid_request_error",
        "A key name is required",
      );
    const id = randomUUID(),
      key = "gw_" + randomBytes(32).toString("base64url");
    db.run(
      "INSERT INTO api_keys VALUES(?,?,?,?,?,NULL)",
      id,
      b.data.name,
      hash(key),
      "active",
      Date.now(),
    );
    return reply.code(201).send({ id, key, name: b.data.name });
  });
  app.delete<{ Params: { id: string } }>(
    "/admin/keys/:id",
    async (req, reply) => {
      db.run("UPDATE api_keys SET status='disabled' WHERE id=?", req.params.id);
      return reply.code(204).send();
    },
  );
  app.get("/admin/conversations", async (req) => {
    const q = filters(req.query);
    checkSearch(q);
    const where =
      "created_at BETWEEN ? AND ? AND (? IS NULL OR model_alias=?) AND (? IS NULL OR client_type=?) AND (? IS NULL OR EXISTS(SELECT 1 FROM requests r WHERE r.conversation_id=conversations.id AND (instr(r.external_request_json,?)>0 OR instr(r.upstream_response_json,?)>0)))";
    const rows = db.all(
      `SELECT * FROM conversations WHERE ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      q.from,
      q.to,
      q.model ?? null,
      q.model ?? null,
      q.client ?? null,
      q.client ?? null,
      q.q ?? null,
      q.q ?? null,
      q.q ?? null,
      q.limit,
      q.offset,
    );
    return {
      data: rows.map((r) => ({ ...r, title: db.decode(r.title) })),
      limit: q.limit,
      offset: q.offset,
    };
  });
  function detail(id: string, raw: unknown) {
    const q = filters(raw);
    const conversation = db.get("SELECT * FROM conversations WHERE id=?", id);
    if (!conversation)
      throw new ApiError(404, "not_found", "Conversation not found");
    const requests: Record<string, any>[] = db
      .all(
        "SELECT * FROM requests WHERE conversation_id=? ORDER BY started_at LIMIT ? OFFSET ?",
        id,
        q.limit,
        q.offset,
      )
      .map((r) => ({
        ...r,
        upstream_request_json: db.decode(r.upstream_request_json),
        upstream_response_json: db.decode(r.upstream_response_json),
        external_request_json: db.decode(r.external_request_json),
      }));
    const ids = requests.map((r) => r.id);
    const messages: Record<string, any>[] = ids.length
      ? db
          .all(
            `SELECT * FROM messages WHERE request_id IN (${ids.map(() => "?").join(",")}) ORDER BY created_at,seq`,
            ...ids,
          )
          .map((m) => ({ ...m, content_json: db.decode(m.content_json) }))
      : [];
    return {
      conversation: { ...conversation, title: db.decode(conversation.title) },
      requests,
      messages,
      limit: q.limit,
      offset: q.offset,
    };
  }
  app.get<{ Params: { id: string } }>("/admin/conversations/:id", async (req) =>
    detail(req.params.id, req.query),
  );
  app.get<{ Params: { id: string }; Querystring: { format?: string } }>(
    "/admin/conversations/:id/export",
    async (req, reply) => {
      const { format = "json", ...pagination } = req.query;
      if (!["json", "md"].includes(format))
        throw new ApiError(
          400,
          "invalid_request_error",
          "Export format must be json or md",
        );
      const d = detail(req.params.id, pagination);
      reply.header(
        "content-disposition",
        `attachment; filename="conversation.${format}"`,
      );
      if (format === "json") return d;
      return reply
        .type("text/markdown")
        .send(
          d.messages
            .map(
              (m) =>
                `## ${m.role} (request ${m.request_id}, seq ${m.seq})\n\n${m.content_json.content}`,
            )
            .join("\n\n"),
        );
    },
  );
  app.delete<{ Params: { id: string } }>(
    "/admin/conversations/:id",
    async (req, reply) => {
      db.transaction(() => {
        const id = req.params.id;
        const conv = db.get(
          "SELECT api_key_id FROM conversations WHERE id=?",
          id,
        );
        db.run("DELETE FROM messages WHERE conversation_id=?", id);
        db.run("DELETE FROM response_contexts WHERE conversation_id=?", id);
        if (conv)
          db.run(
            "DELETE FROM message_mappings WHERE api_key_id=?",
            conv.api_key_id,
          );
        if (c.DELETE_STATS)
          db.run("DELETE FROM requests WHERE conversation_id=?", id);
        else
          db.run(
            "UPDATE requests SET conversation_id=NULL,external_request_json=NULL,upstream_request_json=NULL,upstream_response_json=NULL WHERE conversation_id=?",
            id,
          );
        db.run("DELETE FROM conversations WHERE id=?", id);
      });
      return reply.code(204).send();
    },
  );
  const where = "started_at BETWEEN ? AND ?";
  const aggregate =
    "COUNT(*) AS calls, SUM(status='success') AS success, SUM(status='failed') AS failed, SUM(status='cancelled') AS cancelled, SUM(status='pending') AS pending, AVG(latency_ms) AS avg_latency_ms, MAX(started_at) AS last_request_at, SUM(input_tokens) AS input_tokens, SUM(output_tokens) AS output_tokens";
  app.get("/admin/stats/overview", async (req) => {
    const q = filters(req.query);
    const basic = db.get(
      `SELECT ${aggregate} FROM requests WHERE ${where}`,
      q.from,
      q.to,
    );
    const count = db.get(
      `SELECT COUNT(*) n FROM requests WHERE ${where} AND latency_ms IS NOT NULL`,
      q.from,
      q.to,
    )!.n as number;
    const percentile = (p: number) =>
      count
        ? db.get(
            `SELECT latency_ms FROM requests WHERE ${where} AND latency_ms IS NOT NULL ORDER BY latency_ms LIMIT 1 OFFSET ?`,
            q.from,
            q.to,
            Math.max(0, Math.ceil(count * p) - 1),
          )?.latency_ms
        : null;
    return {
      ...basic,
      success_rate: basic?.calls ? basic.success / basic.calls : null,
      p50_ms: percentile(0.5),
      p95_ms: percentile(0.95),
      p99_ms: percentile(0.99),
      inflight: inflight(),
      token_source: "unknown",
      estimated_cost: null,
      avg_first_byte_ms: db.get(
        `SELECT AVG(first_byte_ms) value FROM requests WHERE ${where} AND stream=1`,
        q.from,
        q.to,
      )?.value,
      status_codes: db.all(
        `SELECT http_status,COUNT(*) calls FROM requests WHERE ${where} GROUP BY http_status`,
        q.from,
        q.to,
      ),
      by_protocol: db.all(
        `SELECT protocol,${aggregate} FROM requests WHERE ${where} GROUP BY protocol`,
        q.from,
        q.to,
      ),
    };
  });
  for (const [route, column] of [
    ["by-key", "api_key_id"],
    ["by-model", "model_alias"],
    ["by-conversation", "conversation_id"],
    ["by-protocol", "protocol"],
    ["errors", "error_code"],
    ["timeseries", "bucket"],
  ] as const)
    app.get("/admin/stats/" + route, async (req) => {
      const q = filters(req.query);
      const group =
        column === "bucket"
          ? `strftime('${q.granularity === "hour" ? "%Y-%m-%dT%H:00:00Z" : "%Y-%m-%dT00:00:00Z"}',started_at/1000,'unixepoch')`
          : column;
      return {
        data: db.all(
          `SELECT ${group} AS ${column},${aggregate} FROM requests WHERE ${where} ${column === "error_code" ? "AND error_code IS NOT NULL" : ""} GROUP BY ${group} ORDER BY ${column} LIMIT ? OFFSET ?`,
          q.from,
          q.to,
          q.limit,
          q.offset,
        ),
      };
    });
}
