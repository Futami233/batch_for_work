import { z } from "zod";
const bool = z.enum(["true", "false"]).transform((x) => x === "true");
const schema = z.object({
  HOST: z.string().default("127.0.0.1"),
  PORT: z.coerce.number().int().min(0).max(65535).default(3000),
  UPSTREAM_URL: z.url().default("http://127.0.0.1:3001/chat"),
  UPSTREAM_COOKIE: z.string().default(""),
  UPSTREAM_CSRF_TOKEN: z.string().default(""),
  ADMIN_API_KEY: z.string().min(24),
  DATABASE_URL: z.string().default("./data/gateway.sqlite"),
  MODEL_ALIASES: z.string().default("upstream-chat,claude-proxy,gpt-proxy"),
  REQUEST_TIMEOUT_MS: z.coerce.number().int().positive().default(60000),
  MAX_BODY_BYTES: z.coerce.number().int().positive().default(1048576),
  MAX_UPSTREAM_BYTES: z.coerce.number().int().positive().default(4194304),
  ARCHIVE_ENABLED: bool.default(true),
  ANONYMIZE_STATS: bool.default(false),
  ARCHIVE_RETENTION_DAYS: z.coerce.number().int().positive().default(30),
  ARCHIVE_ENCRYPTION_KEY: z
    .string()
    .regex(/^[0-9a-f]{64}$/i)
    .optional(),
  SAVE_THOUGHTS: bool.default(false),
  REPLAY_THOUGHTS: bool.default(false),
  EXPOSE_THOUGHTS: bool.default(false),
  RATE_LIMIT_RPM: z.coerce.number().int().positive().default(60),
  KEY_CONCURRENCY: z.coerce.number().int().positive().default(4),
  DELETE_STATS: bool.default(false),
});
export type Config = z.infer<typeof schema>;
export function config(env: Record<string, unknown> = process.env): Config {
  const c = schema.parse(env);
  if (c.ANONYMIZE_STATS && c.ARCHIVE_ENABLED)
    throw Error("ANONYMIZE_STATS requires ARCHIVE_ENABLED=false");
  if (!/^https?:/.test(c.UPSTREAM_URL))
    throw Error("UPSTREAM_URL must use HTTP(S)");
  if ((c.SAVE_THOUGHTS || c.REPLAY_THOUGHTS) && !c.ARCHIVE_ENCRYPTION_KEY)
    throw Error("Thought storage/replay requires encryption");
  if (c.REPLAY_THOUGHTS && !c.SAVE_THOUGHTS)
    throw Error("Replay requires SAVE_THOUGHTS");
  return c;
}
