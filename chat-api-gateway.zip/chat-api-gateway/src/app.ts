import Fastify, { type FastifyRequest } from "fastify";
import { randomUUID, timingSafeEqual } from "node:crypto";
import { Readable } from "node:stream";
import type { Config } from "./config.js";
import { Store, hash } from "./db.js";
import { ApiError } from "./lib/errors.js";
import {
  normalize,
  upstreamHistory,
  capabilities,
  type Message,
  type Protocol,
} from "./normalize.js";
import { callUpstream } from "./upstream.js";
import { output, events } from "./protocols.js";
import { adminRoutes } from "./admin.js";
interface Context {
  id: string;
  start: number;
  key?: string;
  conversation?: string;
  protocol?: Protocol;
  model?: string;
  stream?: boolean;
  controller: AbortController;
  released: boolean;
  limited: boolean;
  done: boolean;
  first?: number;
  error?: string;
  disconnect: boolean;
}
const routes: Record<string, Protocol> = {
  "/v1/chat/completions": "chat",
  "/v1/responses": "responses",
  "/v1/messages": "anthropic",
};
export function createApp(c: Config, transport: typeof fetch = fetch) {
  const db = new Store(c);
  db.purge();
  let healthy = true;
  let inflight = 0;
  const app = Fastify({
    bodyLimit: c.MAX_BODY_BYTES,
    requestTimeout: c.REQUEST_TIMEOUT_MS,
    logger: { level: "info" },
    disableRequestLogging: true,
    requestIdHeader: false,
  });
  const contexts = new WeakMap<FastifyRequest, Context>();
  const limits = new Map<
    string,
    { minute: number; count: number; active: number }
  >();
  const aliases = c.MODEL_ALIASES.split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const release = (x: Context) => {
    if (x.released) return;
    x.released = true;
    inflight--;
    if (x.limited && x.key) {
      const l = limits.get(x.key);
      if (l) l.active--;
    }
  };
  const finalize = (x: Context, status: number) => {
    if (x.done) return;
    x.done = true;
    release(x);
    try {
      db.run(
        "UPDATE requests SET status=?,http_status=?,finished_at=?,latency_ms=?,first_byte_ms=?,error_code=?,client_disconnected=? WHERE id=?",
        x.disconnect ? "cancelled" : status < 400 ? "success" : "failed",
        status,
        Date.now(),
        Date.now() - x.start,
        x.first ?? null,
        x.error ?? null,
        x.disconnect ? 1 : 0,
        x.id,
      );
      if (c.ANONYMIZE_STATS)
        db.run(
          "UPDATE requests SET api_key_id=NULL,conversation_id=NULL WHERE id=?",
          x.id,
        );
    } catch {
      healthy = false;
      app.log.error(
        { request_id: x.id, code: "audit_write_failed" },
        "Audit write failed",
      );
    }
  };
  app.addHook("onRequest", async (req, reply) => {
    const path = req.url.split("?")[0]!;
    if (path.startsWith("/v1/") && req.method === "POST") {
      const x: Context = {
        id: randomUUID(),
        start: Date.now(),
        controller: new AbortController(),
        released: false,
        limited: false,
        done: false,
        disconnect: false,
        protocol: routes[path],
      };
      contexts.set(req, x);
      inflight++;
      try {
        db.run(
          "INSERT INTO requests(id,protocol,endpoint,status,started_at) VALUES(?,?,?,?,?)",
          x.id,
          x.protocol ?? "unknown",
          path,
          "pending",
          x.start,
        );
      } catch {
        healthy = false;
        release(x);
        throw new ApiError(
          503,
          "storage_unavailable",
          "Audit storage unavailable",
        );
      }
      reply.header("x-request-id", x.id);
      reply.raw.on("close", () => {
        if (!reply.raw.writableFinished) {
          x.disconnect = true;
          x.error = "client_disconnected";
          x.controller.abort("client_disconnected");
          finalize(x, 499);
        }
      });
    }
    if (path.startsWith("/admin/") || path === "/admin") {
      // The static login page contains no private information.
      if (path === "/admin" && req.method === "GET") return;
      const provided = String(req.headers["x-admin-key"] ?? "");
      if (
        !timingSafeEqual(
          Buffer.from(hash(provided)),
          Buffer.from(hash(c.ADMIN_API_KEY)),
        )
      )
        throw new ApiError(
          401,
          "authentication_error",
          "Invalid administrator key",
        );
    }
    if (path.startsWith("/v1/")) {
      const auth = req.headers.authorization;
      const key = auth?.startsWith("Bearer ")
        ? auth.slice(7)
        : String(req.headers["x-api-key"] ?? "");
      const row = db.get(
        "SELECT id FROM api_keys WHERE key_hash=? AND status='active'",
        hash(key),
      );
      if (!row)
        throw new ApiError(401, "authentication_error", "Invalid API key");
      db.run(
        "UPDATE api_keys SET last_used_at=? WHERE id=?",
        Date.now(),
        row.id,
      );
      const x = contexts.get(req);
      if (x) {
        x.key = row.id;
        db.run(
          "UPDATE requests SET api_key_id=? WHERE id=?",
          c.ANONYMIZE_STATS ? null : x.key!,
          x.id,
        );
        const minute = Math.floor(Date.now() / 60000);
        let l = limits.get(row.id);
        if (!l) {
          l = { minute, count: 0, active: 0 };
          limits.set(row.id, l);
        }
        if (l.minute !== minute) {
          l.minute = minute;
          l.count = 0;
        }
        if (l.count >= c.RATE_LIMIT_RPM || l.active >= c.KEY_CONCURRENCY) {
          reply.header("retry-after", "60");
          throw new ApiError(
            429,
            "rate_limit_error",
            "Key rate or concurrency limit exceeded",
          );
        }
        l.count++;
        l.active++;
        x.limited = true;
      }
    }
  });
  app.addHook("preValidation", async (req) => {
    const x = contexts.get(req);
    if (x && c.ARCHIVE_ENABLED && req.body !== undefined)
      db.run(
        "UPDATE requests SET external_request_json=? WHERE id=?",
        db.encode(req.body),
        x.id,
      );
  });
  app.addHook("onSend", async (req, _reply, payload) => {
    const x = contexts.get(req);
    if (x) x.first = Date.now() - x.start;
    return payload;
  });
  app.addHook("onResponse", async (req, reply) => {
    const x = contexts.get(req);
    if (x) {
      finalize(x, reply.statusCode);
      app.log.info(
        {
          request_id: x.id,
          status: reply.statusCode,
          latency_ms: Date.now() - x.start,
        },
        "Request complete",
      );
    }
  });
  app.setErrorHandler((error, req, reply) => {
    const x = contexts.get(req);
    const e =
      error instanceof ApiError
        ? error
        : new ApiError(
            (error as any).statusCode === 413
              ? 413
              : (error as any).statusCode === 400
                ? 400
                : 503,
            (error as any).statusCode === 413
              ? "context_too_large"
              : (error as any).statusCode === 400
                ? "invalid_request_error"
                : "internal_error",
            (error as any).statusCode === 413
              ? "Request exceeds size limit"
              : (error as any).statusCode === 400
                ? "Invalid JSON request"
                : "Service unavailable",
          );
    if (x) x.error = e.code;
    reply.code(e.status === 499 ? 499 : e.status).send({
      type: "error",
      error: { type: e.code, code: e.code, message: e.message },
      request_id: x?.id,
    });
  });
  app.get("/healthz", async () => ({ status: "ok" }));
  app.get("/readyz", async (_req, reply) => {
    try {
      db.get("SELECT 1");
      if (!healthy) throw Error();
      return { status: "ready" };
    } catch {
      return reply.code(503).send({ status: "not_ready" });
    }
  });
  app.get("/v1/models", async () => ({
    object: "list",
    data: aliases.map((id) => ({
      id,
      object: "model",
      created: 0,
      owned_by: "configured-upstream-alias",
    })),
  }));
  for (const [path, p] of Object.entries(routes))
    app.post(path, async (req, reply) => {
      const x = contexts.get(req)!;
      const n = normalize(req.body, p);
      if (
        c.ANONYMIZE_STATS &&
        (n.store || n.previous || req.headers["x-conversation-id"])
      )
        throw new ApiError(
          422,
          "unsupported_feature",
          "Anonymous mode requires store=false and no conversation continuation",
        );
      x.model = n.model;
      x.stream = n.stream;
      if (!aliases.includes(n.model))
        throw new ApiError(
          400,
          "model_not_found",
          "Unknown configured model alias",
        );
      let history: Message[] = n.messages;
      let conversation: string | undefined;
      if (n.previous) {
        const previous = db.get(
          "SELECT * FROM response_contexts WHERE id=? AND api_key_id=? AND created_at>=?",
          n.previous,
          x.key!,
          Date.now() - c.ARCHIVE_RETENTION_DAYS * 86400000,
        );
        if (!previous)
          throw new ApiError(
            404,
            "response_not_found",
            "Response context missing, expired or inaccessible",
          );
        history = [...db.decode(previous.history_json), ...history];
        conversation = previous.conversation_id;
      }
      const supplied = req.headers["x-conversation-id"];
      if (
        supplied !== undefined &&
        (typeof supplied !== "string" || !/^conv_[0-9a-f-]{36}$/.test(supplied))
      )
        throw new ApiError(
          400,
          "invalid_request_error",
          "Invalid X-Conversation-Id",
        );
      if (supplied) {
        const existing = db.get(
          "SELECT * FROM conversations WHERE id=? AND api_key_id=?",
          supplied as string,
          x.key!,
        );
        if (!existing)
          throw new ApiError(
            404,
            "conversation_not_found",
            "Conversation missing or inaccessible",
          );
        if (conversation && conversation !== supplied)
          throw new ApiError(
            400,
            "invalid_request_error",
            "Conversation conflicts with previous_response_id",
          );
        conversation = supplied as string;
      }
      conversation ??= "conv_" + randomUUID();
      x.conversation = conversation;
      if (Buffer.byteLength(JSON.stringify(history)) > c.MAX_BODY_BYTES)
        throw new ApiError(
          413,
          "context_too_large",
          "Combined context exceeds size limit",
        );
      const wire = upstreamHistory(history, (prefix) => {
        const mapping = db.get(
          "SELECT * FROM message_mappings WHERE api_key_id=? AND history_hash=? AND created_at>=?",
          x.key!,
          hash(JSON.stringify(prefix)),
          Date.now() - c.ARCHIVE_RETENTION_DAYS * 86400000,
        );
        return mapping
          ? {
              ...(mapping.upstream_message_id
                ? { messageId: mapping.upstream_message_id }
                : {}),
              ...(c.REPLAY_THOUGHTS && mapping.thought
                ? { thoughtContent: db.decode(mapping.thought) }
                : {}),
            }
          : undefined;
      });
      db.transaction(() => {
        if (!c.ANONYMIZE_STATS)
          db.run(
            "INSERT INTO conversations(id,api_key_id,client_type,model_alias,title,created_at,updated_at,last_request_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,last_request_at=excluded.last_request_at",
            conversation!,
            x.key!,
            p,
            n.model,
            c.ARCHIVE_ENABLED
              ? db.encode(
                  history
                    .find((m) => m.role === "user")
                    ?.content.slice(0, 80) ?? "Conversation",
                )
              : null,
            x.start,
            x.start,
            x.start,
          );
        db.run(
          "UPDATE requests SET conversation_id=?,model_alias=?,stream=?,upstream_request_json=?,external_request_json=? WHERE id=?",
          c.ANONYMIZE_STATS ? null : conversation!,
          n.model,
          n.stream ? 1 : 0,
          c.ARCHIVE_ENABLED ? db.encode(wire) : null,
          c.ARCHIVE_ENABLED ? db.encode(req.body) : null,
          x.id,
        );
        if (c.ARCHIVE_ENABLED)
          history.forEach((m, i) =>
            db.run(
              "INSERT INTO messages VALUES(?,?,?,?,?,?,?,?)",
              randomUUID(),
              conversation!,
              x.id,
              i,
              m.role,
              db.encode(m),
              (wire[i] as any).messageId ?? null,
              x.start,
            ),
          );
      });
      reply
        .header("x-conversation-id", conversation)
        .header("x-token-source", "unknown")
        .header("x-stream-mode", "buffered-json");
      if (n.ignored.length)
        reply.header("x-ignored-parameters", n.ignored.join(","));
      const timeout = setTimeout(
        () => x.controller.abort("timeout"),
        c.REQUEST_TIMEOUT_MS,
      );
      let upstream: Awaited<ReturnType<typeof callUpstream>>;
      try {
        upstream = await callUpstream(c, wire, x.controller.signal, transport);
      } finally {
        clearTimeout(timeout);
      }
      if (x.disconnect)
        throw new ApiError(499, "client_disconnected", "Client disconnected");
      const result: any = output(p, n.model, upstream.respMessage);
      if (p === "responses") {
        result.store = n.store;
        result.previous_response_id = n.previous ?? null;
        result.instructions = (req.body as any).instructions ?? null;
      }
      if (c.EXPOSE_THOUGHTS && !n.stream && upstream.thoughtMessage)
        result.upstream_thought = upstream.thoughtMessage;
      const full: Message[] = [
        ...history,
        { role: "assistant", content: upstream.respMessage },
      ];
      const savedRaw = { ...upstream };
      if (!c.SAVE_THOUGHTS) delete savedRaw.thoughtMessage;
      db.transaction(() => {
        db.run(
          "UPDATE requests SET upstream_response_json=? WHERE id=?",
          c.ARCHIVE_ENABLED ? db.encode(savedRaw) : null,
          x.id,
        );
        if (c.ARCHIVE_ENABLED)
          db.run(
            "INSERT INTO messages VALUES(?,?,?,?,?,?,?,?)",
            randomUUID(),
            conversation!,
            x.id,
            history.length,
            "assistant",
            db.encode(full.at(-1)),
            upstream.messageId ?? null,
            Date.now(),
          );
        if (c.ARCHIVE_ENABLED)
          db.run(
            "INSERT OR REPLACE INTO message_mappings VALUES(?,?,?,?,?)",
            x.key!,
            hash(JSON.stringify(full)),
            upstream.messageId ?? null,
            c.SAVE_THOUGHTS && upstream.thoughtMessage
              ? db.encode(upstream.thoughtMessage)
              : null,
            Date.now(),
          );
        if (p === "responses" && n.store)
          db.run(
            "INSERT INTO response_contexts VALUES(?,?,?,?,?)",
            result.id,
            x.key!,
            conversation!,
            db.encode(full),
            Date.now(),
          );
      });
      if (!n.stream) return result;
      reply
        .header("content-type", "text/event-stream; charset=utf-8")
        .header("cache-control", "no-cache")
        .header("x-accel-buffering", "no");
      async function* stream() {
        for (const event of events(p, result, upstream.respMessage)) {
          if (x.controller.signal.aborted) return;
          yield (
            (event.event ? `event: ${event.event}\n` : "") +
            `data: ${typeof event.data === "string" ? event.data : JSON.stringify(event.data)}\n\n`
          );
        }
      }
      return reply.send(Readable.from(stream()));
    });
  adminRoutes(app, db, c, () => inflight);
  const cleanup = setInterval(() => {
    try {
      db.purge();
      for (const [k, l] of limits)
        if (l.active === 0 && l.minute < Math.floor(Date.now() / 60000) - 1)
          limits.delete(k);
    } catch {
      healthy = false;
      app.log.error({ code: "cleanup_failed" }, "Retention cleanup failed");
    }
  }, 3600000);
  cleanup.unref();
  app.addHook("onClose", async () => {
    clearInterval(cleanup);
    db.db.close();
  });
  return { app, db, capabilities };
}
