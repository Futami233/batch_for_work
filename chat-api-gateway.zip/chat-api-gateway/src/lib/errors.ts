export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
  }
}
export const unsupported = (name: string): never => {
  throw new ApiError(
    422,
    "unsupported_feature",
    `Unsupported feature: ${name}`,
  );
};
