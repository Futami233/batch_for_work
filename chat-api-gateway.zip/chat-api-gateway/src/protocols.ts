import { randomUUID } from "node:crypto";
import type { Protocol } from "./normalize.js";
export type Event = { event?: string; data: unknown };
export function output(p: Protocol, model: string, text: string) {
  const id =
    (p === "chat" ? "chatcmpl_" : p === "responses" ? "resp_" : "msg_") +
    randomUUID();
  const created = Math.floor(Date.now() / 1000);
  if (p === "chat")
    return {
      id,
      object: "chat.completion",
      created,
      model,
      choices: [
        {
          index: 0,
          message: { role: "assistant", content: text },
          finish_reason: "stop",
        },
      ],
      usage: null,
    };
  if (p === "anthropic")
    return {
      id,
      type: "message",
      role: "assistant",
      model,
      content: [{ type: "text", text }],
      stop_reason: "end_turn",
      stop_sequence: null,
      usage: { input_tokens: null, output_tokens: null },
    };
  return {
    id,
    object: "response",
    created_at: created,
    status: "completed",
    error: null,
    incomplete_details: null,
    model,
    output: [
      {
        id: "msg_" + randomUUID(),
        type: "message",
        status: "completed",
        role: "assistant",
        content: [{ type: "output_text", text, annotations: [], logprobs: [] }],
      },
    ],
    parallel_tool_calls: false,
    tools: [],
    tool_choice: "none",
    usage: null,
  };
}
export function* events(
  p: Protocol,
  result: any,
  text: string,
): Generator<Event> {
  const chunks = Array.from(text).reduce<string[]>((a, c, i) => {
    if (i % 64 === 0) a.push("");
    a[a.length - 1] += c;
    return a;
  }, []);
  if (p === "chat") {
    const chunk = (delta: unknown, finish_reason: string | null = null) => ({
      id: result.id,
      object: "chat.completion.chunk",
      created: result.created,
      model: result.model,
      choices: [{ index: 0, delta, finish_reason }],
    });
    yield { data: chunk({ role: "assistant", content: "" }) };
    for (const s of chunks) yield { data: chunk({ content: s }) };
    yield { data: chunk({}, "stop") };
    yield { data: "[DONE]" };
    return;
  }
  if (p === "anthropic") {
    yield {
      event: "message_start",
      data: {
        type: "message_start",
        message: { ...result, content: [], stop_reason: null },
      },
    };
    yield {
      event: "content_block_start",
      data: {
        type: "content_block_start",
        index: 0,
        content_block: { type: "text", text: "" },
      },
    };
    for (const s of chunks)
      yield {
        event: "content_block_delta",
        data: {
          type: "content_block_delta",
          index: 0,
          delta: { type: "text_delta", text: s },
        },
      };
    yield {
      event: "content_block_stop",
      data: { type: "content_block_stop", index: 0 },
    };
    yield {
      event: "message_delta",
      data: {
        type: "message_delta",
        delta: { stop_reason: "end_turn", stop_sequence: null },
        usage: { output_tokens: null },
      },
    };
    yield { event: "message_stop", data: { type: "message_stop" } };
    return;
  }
  let seq = 0;
  const ev = (type: string, data: object): Event => ({
    event: type,
    data: { type, sequence_number: seq++, ...data },
  });
  const item = result.output[0],
    part = item.content[0];
  yield ev("response.created", {
    response: { ...result, status: "in_progress", output: [] },
  });
  yield ev("response.in_progress", {
    response: { ...result, status: "in_progress", output: [] },
  });
  yield ev("response.output_item.added", {
    output_index: 0,
    item: { ...item, status: "in_progress", content: [] },
  });
  yield ev("response.content_part.added", {
    item_id: item.id,
    output_index: 0,
    content_index: 0,
    part: { ...part, text: "" },
  });
  for (const s of chunks)
    yield ev("response.output_text.delta", {
      item_id: item.id,
      output_index: 0,
      content_index: 0,
      delta: s,
      logprobs: [],
    });
  yield ev("response.output_text.done", {
    item_id: item.id,
    output_index: 0,
    content_index: 0,
    text,
    logprobs: [],
  });
  yield ev("response.content_part.done", {
    item_id: item.id,
    output_index: 0,
    content_index: 0,
    part,
  });
  yield ev("response.output_item.done", { output_index: 0, item });
  yield ev("response.completed", { response: result });
}
