import { DatabaseSync, type SQLInputValue } from "node:sqlite";
import { mkdirSync, chmodSync, readFileSync } from "node:fs";
import { dirname } from "node:path";
import {
  createHash,
  randomBytes,
  createCipheriv,
  createDecipheriv,
} from "node:crypto";
import type { Config } from "./config.js";
export const hash = (s: string) => createHash("sha256").update(s).digest("hex");
export class Store {
  db: DatabaseSync;
  constructor(public c: Config) {
    if (c.DATABASE_URL !== ":memory:")
      mkdirSync(dirname(c.DATABASE_URL), { recursive: true, mode: 0o700 });
    this.db = new DatabaseSync(c.DATABASE_URL);
    this.db.exec(
      "PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON; PRAGMA secure_delete=ON;",
    );
    this.db.exec(
      readFileSync(new URL("../src/db/001.sql", import.meta.url), "utf8"),
    );
    if (c.DATABASE_URL !== ":memory:") chmodSync(c.DATABASE_URL, 0o600);
    this.run(
      "UPDATE requests SET status='failed',http_status=503,error_code='process_interrupted',finished_at=?,latency_ms=?-started_at WHERE status='pending'",
      Date.now(),
      Date.now(),
    );
  }
  run(sql: string, ...v: SQLInputValue[]) {
    return this.db.prepare(sql).run(...v);
  }
  all(sql: string, ...v: SQLInputValue[]) {
    return this.db.prepare(sql).all(...v) as Record<string, any>[];
  }
  get(sql: string, ...v: SQLInputValue[]) {
    return this.all(sql, ...v)[0];
  }
  transaction<T>(f: () => T): T {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const x = f();
      this.db.exec("COMMIT");
      return x;
    } catch (e) {
      this.db.exec("ROLLBACK");
      throw e;
    }
  }
  encode(x: unknown) {
    const plain = JSON.stringify(x);
    if (!this.c.ARCHIVE_ENCRYPTION_KEY) return plain;
    const iv = randomBytes(12),
      cipher = createCipheriv(
        "aes-256-gcm",
        Buffer.from(this.c.ARCHIVE_ENCRYPTION_KEY, "hex"),
        iv,
      );
    return (
      "enc:" +
      iv.toString("base64") +
      ":" +
      Buffer.concat([cipher.update(plain), cipher.final()]).toString("base64") +
      ":" +
      cipher.getAuthTag().toString("base64")
    );
  }
  decode(s: string | null) {
    if (!s) return null;
    if (!s.startsWith("enc:")) return JSON.parse(s);
    const [, iv, data, tag] = s.split(":");
    const d = createDecipheriv(
      "aes-256-gcm",
      Buffer.from(this.c.ARCHIVE_ENCRYPTION_KEY!, "hex"),
      Buffer.from(iv!, "base64"),
    );
    d.setAuthTag(Buffer.from(tag!, "base64"));
    return JSON.parse(
      Buffer.concat([
        d.update(Buffer.from(data!, "base64")),
        d.final(),
      ]).toString(),
    );
  }
  purge() {
    const cutoff = Date.now() - this.c.ARCHIVE_RETENTION_DAYS * 86400000;
    this.transaction(() => {
      this.run("DELETE FROM messages WHERE created_at<?", cutoff);
      this.run("DELETE FROM response_contexts WHERE created_at<?", cutoff);
      this.run("DELETE FROM message_mappings WHERE created_at<?", cutoff);
      this.run(
        "UPDATE requests SET upstream_request_json=NULL,upstream_response_json=NULL,external_request_json=NULL WHERE started_at<?",
        cutoff,
      );
      this.run("DELETE FROM conversations WHERE updated_at<?", cutoff);
    });
  }
}
