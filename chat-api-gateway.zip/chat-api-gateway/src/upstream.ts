import { z } from "zod";
import type { Config } from "./config.js";
import { ApiError } from "./lib/errors.js";
const responseSchema = z
  .object({
    respMessage: z.string().min(1),
    messageId: z.string().nullish(),
    thoughtMessage: z.string().nullish(),
    response: z.string().optional(),
  })
  .passthrough();
export async function callUpstream(
  c: Config,
  history: unknown[],
  signal: AbortSignal,
  transport: typeof fetch = fetch,
) {
  try {
    const response = await transport(c.UPSTREAM_URL, {
      method: "POST",
      redirect: "error",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        cookie: c.UPSTREAM_COOKIE,
        "x-csrf-token": c.UPSTREAM_CSRF_TOKEN,
      },
      body: JSON.stringify(history),
      signal,
    });
    if (!response.ok) {
      await response.body?.cancel();
      if (response.status === 429)
        throw new ApiError(
          429,
          "upstream_rate_limited",
          "Upstream rate limited",
        );
      if ([401, 403].includes(response.status))
        throw new ApiError(
          502,
          "upstream_auth_error",
          "Upstream authentication failed",
        );
      throw new ApiError(
        response.status >= 500 ? 503 : 502,
        "upstream_http_error",
        "Upstream rejected the request",
      );
    }
    if (
      !/^application\/(?:[\w.+-]+\+)?json(?:\s*;|$)/i.test(
        response.headers.get("content-type") ?? "",
      )
    ) {
      await response.body?.cancel();
      throw new ApiError(
        502,
        "upstream_protocol_error",
        "Expected a complete JSON response",
      );
    }
    const reader = response.body?.getReader();
    if (!reader)
      throw new ApiError(502, "upstream_protocol_error", "Missing response");
    let bytes = 0;
    const chunks: Uint8Array[] = [];
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.length;
      if (bytes > c.MAX_UPSTREAM_BYTES) {
        await reader.cancel();
        throw new ApiError(
          502,
          "upstream_protocol_error",
          "Upstream response exceeds configured size",
        );
      }
      chunks.push(value);
    }
    let raw: unknown;
    try {
      raw = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    } catch {
      throw new ApiError(
        502,
        "upstream_protocol_error",
        "Invalid upstream JSON",
      );
    }
    const parsed = responseSchema.safeParse(raw);
    if (!parsed.success)
      throw new ApiError(
        502,
        "upstream_protocol_error",
        "Invalid upstream text response",
      );
    // Only the documented terminal value is accepted; other values are never guessed.
    if (parsed.data.response !== undefined && parsed.data.response !== "End")
      throw new ApiError(
        502,
        "upstream_protocol_error",
        "Unverified upstream response state",
      );
    return parsed.data;
  } catch (e) {
    if (e instanceof ApiError) throw e;
    if (signal.aborted)
      throw new ApiError(
        signal.reason === "client_disconnected" ? 499 : 504,
        signal.reason === "client_disconnected"
          ? "client_disconnected"
          : "upstream_timeout",
        "Request cancelled or timed out",
      );
    throw new ApiError(503, "upstream_unavailable", "Upstream unavailable");
  }
}
