import { z } from "zod";
import { ApiError, unsupported } from "./lib/errors.js";
export type Protocol = "chat" | "responses" | "anthropic";
export type Message = {
  role: "system" | "developer" | "user" | "assistant";
  content: string;
};
export const capabilities = {
  text: true,
  buffered_sse: true,
  native_stream: false,
  tools: false,
  images: false,
  audio: false,
};
const block = z
  .object({ type: z.string(), text: z.string().optional() })
  .passthrough();
const content = z.union([z.string(), z.array(block)]);
const message = z
  .object({
    role: z.enum(["system", "developer", "user", "assistant", "tool"]),
    content,
  })
  .strict();
const common = {
  model: z.string().min(1),
  stream: z.boolean().default(false),
  temperature: z.number().min(0).max(2).optional(),
  top_p: z.number().min(0).max(1).optional(),
};
const schemas = {
  chat: z
    .object({
      ...common,
      messages: z.array(message).min(1),
      max_tokens: z.number().int().positive().optional(),
      max_completion_tokens: z.number().int().positive().optional(),
      n: z.literal(1).optional(),
      stream_options: z
        .object({ include_usage: z.boolean().optional() })
        .strict()
        .optional(),
    })
    .strict(),
  anthropic: z
    .object({
      ...common,
      max_tokens: z.number().int().positive(),
      system: content.optional(),
      messages: z.array(message).min(1),
    })
    .strict(),
  responses: z
    .object({
      ...common,
      input: z.union([
        z.string(),
        z
          .array(
            z
              .object({
                type: z.literal("message").optional(),
                role: z.enum(["system", "developer", "user", "assistant"]),
                content,
              })
              .strict(),
          )
          .min(1),
      ]),
      instructions: z.string().optional(),
      previous_response_id: z.string().optional(),
      store: z.boolean().default(true),
      max_output_tokens: z.number().int().positive().optional(),
    })
    .strict(),
};
export type Normalized = {
  model: string;
  stream: boolean;
  messages: Message[];
  store: boolean;
  previous?: string;
  ignored: string[];
};
function textContent(c: z.infer<typeof content>, p: Protocol): string {
  if (typeof c === "string") return c;
  return c
    .map((b) => {
      if (
        ![
          "text",
          ...(p === "responses" ? ["input_text", "output_text"] : []),
        ].includes(b.type)
      )
        unsupported(b.type);
      if (typeof b.text !== "string")
        throw new ApiError(
          400,
          "invalid_request_error",
          "Text block requires text",
        );
      if (Object.keys(b).some((k) => !["type", "text"].includes(k)))
        unsupported("content block properties");
      return b.text;
    })
    .join("");
}
export function normalize(raw: unknown, p: Protocol): Normalized {
  if (raw && typeof raw === "object") {
    for (const k of [
      "tools",
      "tool_choice",
      "functions",
      "function_call",
      "thinking",
      "response_format",
    ])
      if (k in raw) unsupported(k);
    const v = raw as any;
    if (Array.isArray(v.messages))
      for (const m of v.messages)
        if (m.tool_calls || m.tool_call_id || m.role === "tool")
          unsupported("tools");
  }
  const parsed = schemas[p].safeParse(raw);
  if (!parsed.success) {
    if (parsed.error.issues.some((i) => i.code === "unrecognized_keys"))
      unsupported("unknown request properties");
    throw new ApiError(
      400,
      "invalid_request_error",
      "Request does not match the supported text schema",
    );
  }
  const b = parsed.data as any;
  let messages: Message[] = [];
  if (p === "responses") {
    if (b.instructions)
      messages.push({ role: "system", content: b.instructions });
    if (typeof b.input === "string")
      messages.push({ role: "user", content: b.input });
    else
      messages.push(
        ...b.input.map((m: any) => ({
          role: m.role,
          content: textContent(m.content, p),
        })),
      );
  } else {
    if (p === "anthropic" && b.system)
      messages.push({ role: "system", content: textContent(b.system, p) });
    messages.push(
      ...b.messages.map((m: any) => {
        if (p === "anthropic" && !["user", "assistant"].includes(m.role))
          throw new ApiError(
            400,
            "invalid_request_error",
            "Messages roles must be user or assistant",
          );
        return { role: m.role, content: textContent(m.content, p) };
      }),
    );
  }
  return {
    model: b.model,
    stream: b.stream,
    messages,
    store: b.store ?? false,
    previous: b.previous_response_id,
    ignored: [
      "temperature",
      "top_p",
      "max_tokens",
      "max_completion_tokens",
      "max_output_tokens",
    ]
      .filter((k) => k in b)
      .concat(
        b.stream_options?.include_usage ? ["stream_options.include_usage"] : [],
      ),
  };
}
export function upstreamHistory(
  messages: Message[],
  lookup: (
    prefix: Message[],
  ) => { messageId?: string; thoughtContent?: string } | undefined,
) {
  return messages.map((m, i) => {
    if (m.role === "system" || m.role === "developer")
      return {
        role: "user",
        content: `[BEGIN DOWNGRADED ${m.role.toUpperCase()} CONTEXT; JSON STRING]\n${JSON.stringify(m.content)}\n[END DOWNGRADED CONTEXT]`,
        fileList: [],
        imageList: [],
      };
    if (m.role === "user") return { ...m, fileList: [], imageList: [] };
    return { ...m, ...lookup(messages.slice(0, i + 1)) };
  });
}
