import { config } from "./config.js";
import { createApp } from "./app.js";
process.umask(0o077);
const c = config();
const { app } = createApp(c);
for (const signal of ["SIGTERM", "SIGINT"])
  process.once(signal, () => {
    const deadline = setTimeout(
      () => process.exit(1),
      c.REQUEST_TIMEOUT_MS + 5000,
    );
    deadline.unref();
    void app.close().then(() => {
      clearTimeout(deadline);
      process.exit(0);
    });
  });
try {
  await app.listen({ host: c.HOST, port: c.PORT });
} catch {
  app.log.error({ code: "startup_failed" }, "Startup failed");
  process.exit(1);
}
