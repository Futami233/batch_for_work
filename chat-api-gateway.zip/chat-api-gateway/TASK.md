# TASK.md — Node.js 多协议聊天 API 代理网关

## 0. 任务目标

请作为资深 Node.js/TypeScript 工程师，在当前仓库中**实现、测试并文档化**一个可部署的聊天 API 代理服务：将一个现有、采用 Cookie + CSRF 鉴权的上游聊天 API，转换为尽可能兼容 OpenAI API 与 Anthropic Messages API（供 Claude Code 使用）的接口；另外实现**完整聊天存档**与**调用量统计**。

**不要只输出设计说明或伪代码**：创建可运行项目、数据库迁移、自动测试、Docker 部署文件、README、环境变量模板及兼容性报告。优先确保真实可用、行为透明、功能边界明确。

## 1. 已知上游协议（来自用户截图）

### 1.1 请求

- 请求方式：`POST ${UPSTREAM_URL}`（实际 URL 未提供，以环境变量配置）。
- 请求头：
  - `Content-Type: application/json`
  - `Cookie: MMHUTHTOKEN=...; MMUSERID=...; MMCSRF=...`（**请与实际抓包逐字核对 Cookie 名称**；截图小字可能存在识别误差，支持整段 `UPSTREAM_COOKIE` 原样配置）
  - `X-Csrf-Token: ...`
- 请求体为**完整聊天历史数组**，而不是 `{messages: [...]}` 包装对象。
- 已知条目示例：

```json
[
  {
    "role": "user",
    "content": "客户提问1",
    "fileList": [],
    "imageList": []
  },
  {
    "role": "assistant",
    "content": "AI回复1",
    "messageId": "AI回复1的ID",
    "thoughtContent": "AI回复1的思考内容"
  },
  {
    "role": "user",
    "content": "基于AI回复1客户提问2",
    "fileList": [],
    "imageList": []
  }
]
```

### 1.2 响应

**已确认的硬性约束：上游只能全量返回非流式 JSON 响应。禁止尝试连接、探测或协商上游 SSE，禁止向上游请求流式模式；下游的 `stream` 参数仅控制代理层输出，不得透传给上游。所有流式兼容仅在代理层完成：等待上游完整响应接收并校验成功后，再按下游协议生成 SSE 事件。此方式不是实时流式推理，不能缩短首 token 等待时间。**

截图提供如下结构（字段示例，不保证所有字段始终有值）：

```json
{
  "fileSendMessages": [],
  "messageId": "上游消息ID",
  "requestTime": "",
  "respMessage": "回复内容",
  "response": "End",
  "thoughtMessage": "思考内容"
}
```

- `respMessage` 是输出文本；`thoughtMessage` 为单独的上游思考内容，是否可展示、保存和回传必须可配置，默认**不向下游暴露**。
- `messageId` 应保留在上游消息映射和归档中，供下轮历史重放。
- `response: "End"` 只是截图示例，**不可自行假定**其余取值、流协议、错误码、分页或工具调用行为。
- 上游示例展示文本输入及空的 `fileList`/`imageList`；**不代表文件、图像或工具调用已经可用**。

### 1.3 尚待核实（不得凭空实现成“已支持”）

实际地址、Cookie 名称与有效期、CSRF 更新机制、是否存在独立会话 ID、历史上下文上限、最大输入长度、请求超时、频控、错误响应结构、工具调用原生支持、附件格式、token usage、`thoughtMessage` 的使用权限。上游仅全量返回已确认，不再核实或探测原生流式模式。

**优先提供离线 mock 上游与契约测试**；如果没有真实凭据，不能谎称已完成上游实测。不得把真实 Cookie/CSRF、原始凭据或私密聊天内容放进仓库、错误消息、普通应用日志或示例文件。

## 2. 推荐技术栈与目录

- Node.js 22+、TypeScript（strict）、Fastify、Zod（请求校验）、undici/fetch；pnpm。
- SQLite + Drizzle ORM（或等价的轻量 migration 方案），打开 WAL、设置 busy timeout 和明确的数据保留策略。
- Vitest 测试，Pino 结构化日志，Dockerfile + docker-compose.yml。
- API 文档以 OpenAPI 和 README 为主；简单自托管管理页面可用静态 HTML/轻量前端（无需大型前端框架）。
- 推荐模块划分：`src/config`、`src/upstream`、`src/normalization`、`src/protocols/openai`、`src/protocols/anthropic`、`src/services/archive`、`src/services/usage`、`src/services/auth`、`src/routes/admin`、`src/db`、`src/lib/sse`、`tests`。
- API 适配层与上游传输层解耦；使用中立的内部消息模型（文本、system、user、assistant、tool_call、tool_result、图片引用、消息关联 ID、usage）并定义能力标志。

## 3. 外部协议与兼容性

### 3.1 通用 API

- `GET /healthz`（不暴露凭据）与 `GET /readyz`。
- `GET /v1/models`：返回用户配置的**模型别名**，例如 `upstream-chat`、`claude-proxy`、`gpt-proxy`，不宣称它们是真实 OpenAI/Anthropic 模型。
- 服务端支持多下游 Key；校验 `Authorization: Bearer <key>`（OpenAI）及 `x-api-key: <key>`（Anthropic）；管理路径要求单独的 admin key。
- 允许配置 `MODEL_ALIASES`，将下游模型名映射至相同上游能力，拒绝未配置模型或明确记录 fallback；不要假装切换到了不同真实模型。

### 3.2 OpenAI Chat Completions

实现 `POST /v1/chat/completions`：

- 输入至少支持 `model`、`messages`（system/developer/user/assistant）、`stream`、`temperature`、`max_tokens` 等常见字段；不能映射的参数应有明确的忽略/拒绝策略并在 README 标出，不得暗中承诺温度或 token 限制有效。
- 将 `system`、`developer` 消息用**可审计且有边界标记**的策略适配为上游可接收的文本上下文。不得假装上游拥有原生同级指令优先级；记录系统提示词降级处理的风险。
- 从已知上游响应生成合法的 `chat.completion`，包含 `id`、`object`、`created`、`model`、`choices[0].message`、`finish_reason`、`usage`（如果是估算则内部明确标注；标准 usage 字段仅填可靠数字，避免伪造精确值）。
- `stream=true` 时，仅由代理层在**收到并校验上游完整响应后**发出格式正确的 `text/event-stream`，逐个 `chat.completion.chunk` 并以 `data: [DONE]` 结束；必须说明这不是实时流式推理，不能缩短首 token 等待时间，禁止连接上游 SSE。
- 工具调用 `tools/tool_choice`：如果未通过能力验证，返回清晰的 `unsupported_feature`（如 HTTP 422），不要默默删除工具定义。

### 3.3 OpenAI Responses API

实现 `POST /v1/responses` 的**明确限定子集**，至少支持文本 input、instructions、model、stream 及基本会话延续；正常返回 `response` 对象及 `output` 文本项。

- SSE 使用符合 Responses 协议的语义事件序列，如 `response.created`、`response.in_progress`、`response.output_item.added`、`response.content_part.added`、`response.output_text.delta`、`response.output_text.done`、`response.content_part.done`、`response.output_item.done`、`response.completed`；具体事件字段按官方规范实现。
- 上述事件仅由代理层在收到并校验上游完整响应后生成，不连接上游 SSE。
- 支持 `previous_response_id` 时，必须由服务端持久化并回放对应历史；查不到、过期或越权应明确报错。`store=false` 不应持久化可重用的响应上下文（审计存档是否仍保留由独立隐私策略决定，在文档明确）；如暂不支持则返回显式错误。
- 未实现的内建工具、图像/音频、计算机使用或 function calling 不能返回伪造成功；提供 capability matrix。

### 3.4 Anthropic Messages（Claude Code 目标）

实现 `POST /v1/messages`：

- 接受 `x-api-key`、`anthropic-version` 等兼容请求头；至少支持 `model`、`max_tokens`、`system`、`messages`、`stream`。
- 解析 Anthropic content blocks；文本请求转换成上游历史数组；非流式返回 `id`、`type: "message"`、`role: "assistant"`、`model`、`content: [{type:"text",text:...}]`、`stop_reason`、`stop_sequence`、`usage`。
- 流式返回正确序列：`message_start`、`content_block_start`、`content_block_delta`、`content_block_stop`、`message_delta`、`message_stop`，SSE 必须有正确 `event:`/`data:` 结构；仅由代理层在收到并校验上游完整响应后生成，不连接上游 SSE；在错误/客户端中断时正确结束。
- **Claude Code 核心兼容性门槛：**它要求模型能够产生结构化 `tool_use`，接受并延续 `tool_result`，以及处理多轮工具执行。先验证上游是否具有原生工具/函数调用能力。如果只有普通 `respMessage` 文本，单纯格式转换无法保证 Claude Code 的编辑文件、运行命令等能力。
- 若上游确实没有原生工具协议，可将受控的**工具调用结构化文本输出适配器**作为单独的实验功能标志：发送工具 schema 与严格 JSON 输出指令、解析并校验工具名称与参数、输出合法 `tool_use`、接收匹配 `tool_result` 后再生成下一轮；设置 JSON schema 校验、重试上限、防 prompt injection、工具调用数量限制、结果长度限制、ID 关联以及安全失败。**此策略不等于真正原生工具能力，不保证可靠性**；默认关闭，仅在端到端测试通过后标记实验支持。
- 不要在代理进程**代用户执行 shell / 文件写入**；执行由 Claude Code 客户端自己负责。不得伪造工具调用或工具结果。
- 按目标 Claude Code 版本实际发出的请求进行集成测试（包括工具、流式、模型发现/探测），提供已测试版本和使用说明；如果不能完整支持则 README 明确写“Anthropic Messages 文本兼容，Claude Code Agent 模式不保证工作”，不能声称完全兼容。

## 4. 会话历史、上下文转换与消息完整性

- 上游每轮发送整个历史数组，必须按照下游每次请求带来的历史**确定性重建**，避免双重拼接和重复计费；仅在支持 `previous_response_id` 等服务端状态场景从本地存档恢复。
- assistant 历史消息需尽可能重放对应上游 `messageId`、`thoughtContent`；未从上游获得时不伪造。默认禁止把 `thoughtMessage` 当作可暴露的公开 chain-of-thought 下发；如果上游需要其续聊，单独加密/权限管理并限定内部重放。
- `fileList`、`imageList` 暂按空数组传输，检测到不支持的内容块时清晰拒绝；验证真实上游格式后才能实现附件能力。
- 提供请求长度限制、上下文过长的 413/422 处理，不能悄悄截断关键消息；必要时设计可配置的显式截断/摘要策略（默认禁用）。
- tool_use/tool_result 必须维持顺序及 ID 对应关系，不能当普通用户文字偷偷吞掉；缺少能力时显式报错。

## 5. 聊天存档（必做）

使用 SQLite 保留每一次**外部请求**及对应结果，并能按会话追溯：

- `api_keys`: `id`, `name`, `key_hash`, `status`, `created_at`, `last_used_at`。仅保存 key 的不可逆哈希，明文只在创建时显示一次。
- `conversations`: `id`, `api_key_id`, `client_type`, `model_alias`, `title`, `created_at`, `updated_at`, `last_request_at`。
- `messages`: `id`, `conversation_id`, `request_id`, `seq`, `role`, `content_json`, `upstream_message_id`, `created_at`；原样 JSON 保留结构，兼容工具块及附件引用。
- `requests`: `id`, `conversation_id`, `api_key_id`, `protocol`, `endpoint`, `model_alias`, `status`, `http_status`, `started_at`, `finished_at`, `latency_ms`, `error_code`, `upstream_request_json`, `upstream_response_json`, `input_tokens`, `output_tokens`, `token_source`, `stream`, `client_disconnected`。
- `usage_daily` 或可从 requests 高效聚合的索引/视图；不要因预聚合造成双重计数。
- 增加 `conversation_id` 生成与传播策略：可支持自定义 `X-Conversation-Id`（按 API key 隔离）及无 ID 的自动生成；客户端每次携带完整历史但不传会话 ID 时，不能假定不同请求一定属于同一会话，明确归档关联策略（例如返回响应头 ID 并由调用方透传）。
- 按 `request_id` 幂等写入，事务写库，异常请求也留审计记录；上下游完整文本与原始响应都应可检索，避免同一轮重复插入多份历史消息。
- 默认存档完整对话，支持 `ARCHIVE_ENABLED`、`ARCHIVE_RETENTION_DAYS`、清理策略及管理员删除会话；明确 `store=false` 和归档的关系，允许为隐私要求禁用内容归档但保留匿名聚合统计。
- 默认**不保存** Cookie/CSRF、下游原始 API Key、Authorization、敏感请求头；支持按需对存档内容进行加密，设置数据库文件权限和备份说明。

### 存档管理 API

- `GET /admin/conversations`：分页、时间/客户端/模型筛选。
- `GET /admin/conversations/:id`：完整消息时间线及调用记录。
- `GET /admin/conversations/:id/export?format=json|md`：导出对话。
- `DELETE /admin/conversations/:id`：删除对话及关联内容（统计保留规则可配置）。
- 所有 `/admin/*` 使用 `X-Admin-Key` 或单独管理鉴权，不能用普通客户端 Key 访问。

## 6. 调用量统计（必做）

每一次外部请求恰好计数一次（包括失败、超时、取消、上游鉴权失败），支持：

1. 总调用次数、成功/失败/取消次数、状态码及错误类型分布。
2. 按小时/天、API Key、客户端协议（OpenAI Chat/Responses/Anthropic）、模型别名及会话统计。
3. p50/p95/p99 延迟、平均耗时、最近调用时间、并发中请求数（运行时指标）。
4. 输入/输出 Token 用量：**优先使用上游真实 usage**；截图没有 usage，后备可使用明确标记的 tokenizer 估算，无法可靠估算时记录 null，禁止把估算宣称为真实消耗。
5. `estimated_cost` 仅在管理员明确配置模型价格后展示，且标记为估算；未知价格不显示/记 null。
6. SSE 首字节延迟与总耗时分开记录；明确“上游非流式 → 下游伪流式”场景。

管理 API：

- `GET /admin/stats/overview?from=...&to=...`
- `GET /admin/stats/timeseries?granularity=hour|day&from=...&to=...`
- `GET /admin/stats/by-key?from=...&to=...`
- `GET /admin/stats/by-model?from=...&to=...`
- `GET /admin/stats/errors?from=...&to=...`
- `GET /admin/keys`、`POST /admin/keys`、`DELETE /admin/keys/:id`（或禁用接口）。

实现一个最简 `/admin` 管理仪表盘（使用管理凭据登录），展示调用趋势、成功率、延迟和 Token 估算，并可检索/导出聊天存档。后台接口必须有分页和查询范围限制。

## 7. 网络可靠性、安全与运维

- 配置：`PORT`、`HOST`（默认 127.0.0.1，Docker 中可显式设置 0.0.0.0）、`UPSTREAM_URL`、`UPSTREAM_COOKIE`、`UPSTREAM_CSRF_TOKEN`、`ADMIN_API_KEY`、`DATABASE_URL`、`MODEL_ALIASES`、`REQUEST_TIMEOUT_MS`、`MAX_BODY_BYTES`、`ARCHIVE_ENABLED`、`ARCHIVE_RETENTION_DAYS` 等。
- 统一下游错误 JSON；区分 400 参数错误、401/403 鉴权错误、422 不支持能力、429 限流、502 上游协议错误、503 上游不可用、504 超时。
- 外部 Key 限流（每分钟请求和并发上限），可以配置；上游遇到 429/5xx 时采用**有界且仅对安全可重试条件生效**的退避，防重复产生聊天与统计记录。
- 为上游请求建立 AbortController，处理下游客户端断连并释放资源。真实上游 URL 仅从可信配置读取，避免用户提供任意代理 URL 引发 SSRF。
- 安全日志仅包含 request ID、耗时、状态等元数据；不得输出 Cookie、CSRF、明文 Key 和完整聊天（聊天仅存授权的存档数据库）。
- 处理 JSON 解析失败、空回复、奇怪的 content type、上游非 2xx、未知 `response` 状态、断流、数据库磁盘满及并发竞争。
- 允许通过 `.env` 本地开发、Docker Compose 持久化 SQLite；提供优雅关机、数据库迁移和备份恢复指引。

## 8. 测试计划（必须自动化）

建立可配置的 mock upstream，不依赖真实凭据完成 CI：

- 截图给出的用户/assistant 历史数组、`messageId`、`thoughtContent` 输入映射测试。
- `respMessage`/`thoughtMessage`/`messageId` 响应解析与错误路径。
- 验证所有下游流式请求仍使用上游非流式 JSON 请求，不透传 `stream`、不请求 `text/event-stream`、不探测上游 SSE；上游完整响应接收并校验前不得发送下游 SSE 事件。意外返回上游 SSE 时按协议错误处理，不解析或回退为上游流式连接。
- OpenAI Chat Completions 非流式和 SSE 流式（使用 OpenAI 官方 SDK 做客户端契约测试）。
- Responses API 非流式与事件顺序、`previous_response_id` 隔离与缺失场景。
- Anthropic Messages 非流式和 SSE（使用 Anthropic 官方 SDK 做客户端契约测试）。
- 工具调用默认拒绝；实验适配器启用时必须测试合法/非法 JSON、错误 tool ID、tool_result 往返及多轮调用，无真实支持时保持失败而非假成功。
- 数据库会话、归档完整性、删除、Key 隔离、分页查询、统计每日汇总、异常请求只计数一次。
- 并发请求、上游超时、401/403、429、5xx、客户端断连、无效 JSON、数据库写失败。
- 只在用户提供真实测试凭据时运行可选 live integration suite，避免泄露敏感数据。

## 9. README 必须提供的调用示例

### OpenAI SDK

```ts
import OpenAI from 'openai';
const client = new OpenAI({
  apiKey: process.env.PROXY_API_KEY,
  baseURL: 'http://127.0.0.1:3000/v1'
});
const completion = await client.chat.completions.create({
  model: 'gpt-proxy',
  messages: [{ role: 'user', content: '你好' }]
});
console.log(completion.choices[0]?.message?.content);
```

### Anthropic SDK

```ts
import Anthropic from '@anthropic-ai/sdk';
const client = new Anthropic({
  apiKey: process.env.PROXY_API_KEY,
  baseURL: 'http://127.0.0.1:3000'
});
const message = await client.messages.create({
  model: 'claude-proxy',
  max_tokens: 1024,
  messages: [{ role: 'user', content: '你好' }]
});
console.log(message.content);
```

### Claude Code

提供与**实测 Claude Code 版本**匹配的配置和启动命令（通常涉及 `ANTHROPIC_BASE_URL`、`ANTHROPIC_AUTH_TOKEN` 或匹配版本支持的认证配置及模型别名）；注意避免默认 Anthropic 认证冲突。必须写明：“文本 Messages API 可用”不等于“Claude Code 的工具和 Agent 模式可用”，后者需要独立实测通过。

### curl

README 再提供 `/v1/chat/completions`、`/v1/responses`、`/v1/messages`、管理统计与聊天导出的 curl 示例（不含真凭据）。

## 10. 实现顺序

1. 初始化 TypeScript 工程、配置/校验、鉴权、数据库 migration、mock 上游。
2. 实现上游 adapter 与内部标准消息模型，验证多轮历史、messageId、错误分支。
3. 实现 OpenAI Chat Completions，先非流式后 SSE。
4. 实现 Anthropic Messages 文本接口，先非流式后 SSE；追加 Claude Code 工具能力研究及实验适配器（若可行）。
5. 实现 OpenAI Responses API 的文本子集及 history storage。
6. 实现存档服务、统计服务、管理 API、简易仪表盘。
7. 安全、稳定性、集成测试、Docker、README、兼容性矩阵。

## 11. 验收标准（Definition of Done）

- `pnpm install && pnpm test && pnpm build` 成功，`pnpm dev` 可本地运行，`docker compose up -d` 可部署。
- 不接真实上游时，mock API 可跑通所有文本协议端点；有真实凭据时按 README 可切换到真实上游。
- OpenAI 官方 SDK、Anthropic 官方 SDK 均可成功完成多轮**文本**会话（包括流式模式），回传的上游历史包含正确的 ID 和对应内容。
- 每次请求可被检索归档，包含用户与 assistant 文本及可追溯的元数据；不泄露密钥。
- 管理员可以查看调用次数、按时间/Key/协议统计的成功率、延迟和 Token **估算**，可导出会话。
- 失败、超时与断连不会出现重复统计、无界重试或伪造成功。
- 上游始终按全量非流式 JSON 协议调用，禁止连接或探测上游 SSE；三个下游协议的流式兼容均只在代理层完成，README 与兼容性矩阵明确标注为完整响应后的 SSE 分块输出。
- 提交 `COMPATIBILITY.md`：逐项标注 OpenAI Chat、Responses、Anthropic Messages、Claude Code 的文本/stream/tools/images 等能力为 `verified` / `experimental` / `unsupported`，写出运行环境、版本与测试证据。
- 若没有证明工具调用链可靠，**明确把 Claude Code Agent 模式列为 unsupported/experimental，不把整体项目称为完全兼容**。

## 12. 交付物

完整代码仓库、`.env.example`、`README.md`、`COMPATIBILITY.md`、数据库 schema/migration、测试用 mock fixtures、Vitest 测试、Dockerfile、compose 文件、管理页面及必要的脚本。最终答复列出运行方式、测试结果、未验证项、协议差异和后续需要用户提供的上游配置。

## 13. 技术参考

实现前参考官方实时文档，避免猜测协议：

- OpenAI function calling：https://developers.openai.com/api/docs/guides/function-calling
- OpenAI Responses streaming events：https://developers.openai.com/api/reference/resources/responses/streaming-events
- Anthropic Messages API：https://docs.anthropic.com/en/api/messages
- Anthropic streaming：https://docs.anthropic.com/en/api/messages-streaming

**现在开始实施。**如果上游接口能力不足，不要为了“完成”而伪造工具调用或真实流式能力；先交付可靠的文本兼容网关，再用可开关的实验模块拓展 Claude Code 支持。
