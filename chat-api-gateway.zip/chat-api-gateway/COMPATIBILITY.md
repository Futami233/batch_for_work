# 兼容性报告

验证日期：2026-11-16。`verified` 仅表示本项目离线 mock / SDK 契约测试通过，不表示真实上游或模型能力通过验证。

| 能力 | OpenAI Chat | OpenAI Responses | Anthropic Messages | Claude Code |
|---|---|---|---|---|
| 单轮/多轮纯文本 | verified | verified | verified | unsupported（客户端未实测） |
| 完整 JSON 后生成 SSE | verified | verified | verified | unsupported（客户端未实测） |
| 原生实时 token streaming | unsupported | unsupported | unsupported | unsupported |
| 工具定义、tool_use/tool_result、function calling | unsupported | unsupported | unsupported | unsupported |
| 图片、文件、音频 | unsupported | unsupported | unsupported | unsupported |
| previous_response_id 持久化、Key 隔离、store=false | 不适用 | verified | 不适用 | 不适用 |
| 真实 token usage / 精确计费 | unsupported | unsupported | unsupported | unsupported |
| 温度、生成长度控制 | unsupported（校验后显式忽略） | unsupported（校验后显式忽略） | unsupported（校验后显式忽略） | unsupported |
| 系统优先级 | unsupported（降级文本） | unsupported（降级文本） | unsupported（降级文本） | unsupported |
| 原生模型切换/发现 | unsupported（仅配置别名列表） | 同左 | 同左 | unsupported |

没有 experimental 工具实现；工具链可靠性无证据，因此不开启任何“JSON 假工具”适配器。网关不执行客户端命令或文件操作。**Anthropic Messages 文本兼容，Claude Code Agent 模式不保证工作。**

## 已执行环境

- macOS / arm64，Node.js v26.8.2。
- TypeScript 5.9.3，Fastify 5.12.8，Zod 4.6.7，Vitest 4.1.12。
- OpenAI 官方 SDK 6.49.0，Anthropic 官方 SDK 0.137.0。
- SQLite 使用 Node 内置驱动，轻量 SQL migration（无需原生 npm 编译依赖）。
- 默认测试使用 Fastify inject、注入 fetch 和真实官方 SDK SSE 解码器，不依赖网络端口或真实凭据。
- 编译与默认测试通过：29 passed、2 skipped，共 31 项；详见命令输出。两项真实 localhost socket 测试在当前 sandbox 中跳过（EPERM 禁止监听），可用 `pnpm test:network` 执行。
- pnpm 11.25.0 通过环境内已安装运行时执行 test/build；因 npm 风格已有依赖目录，执行时关闭了 pnpm 的自动安装检查。联网 pnpm install 未验证。npm package-lock-only 离线依赖校验成功；Docker 使用 npm ci。
- 未运行 Docker/Compose（本环境没有 Docker），未运行真实上游 live suite，未安装/测试 Claude Code，CI 文件尚未经远端运行。

## 自动化证据

`tests/gateway.test.ts` 与 `tests/store.test.ts` 覆盖：

- OpenAI Chat SDK 非流式、多轮、SSE；Anthropic SDK 非流式、多轮、SSE；Responses SDK output_text、事件顺序和 sequence_number。
- 历史数组、空 fileList/imageList、assistant messageId 的同 Key 前缀匹配；显式允许时加密保存并内部重放 thoughtContent；默认不回传 thought。
- 三种下游 SSE 均等待完整 upstream JSON，Accept 固定 application/json，无 stream 字段，无上游 SSE 探测/回退。
- unknown content type、SSE、坏 JSON、空文本、未知 response 状态、401/403、429、500、超时；每次请求只计数一次、不自动重试。
- tools/images/未知字段拒绝、无效模型、坏请求 JSON、鉴权隔离、长度/rpm/并发限制。
- Responses 上下文延续、越权/缺失与 store=false、归档开关、加密、管理分页/导出/删除、保留期清理、统计及存储写失败时 fail closed。
- localhost 测试单独验证首字节时序与客户端断连释放资源；当前环境未执行这些真实网络断言。

## 显式差异

1. 全部流式都是**上游完整非流式 JSON → 代理 SSE 分块**，不能提前输出真实 token。
2. 未知 usage 返回 null，Anthropic 数字型 usage 与严格官方 schema 有差异；测试 SDK 的运行时解码接受，不能推断所有客户端接受。
3. system/developer 转为带界限的普通 user 上下文；不具备原生指令层级，也不能用边界抵御所有 prompt injection。
4. Responses 是限定子集；instructions 随历史延续保留，不实现官方自动替换上一轮 instructions 的语义。无 retrieve/delete response 或内建工具。
5. 模型名只是别名；`/v1/models` 使用 OpenAI list 形状，不提供 Anthropic 原生模型详情 API。anthropic-version 头接受但不切换协议版本。
6. 截图中的 Cookie 名称、会话字段、附件/工具格式、token、CSRF 更新方式尚未获得真实抓包证据。只有缺失/End 的 response 状态被接受，其他值安全失败。
7. 统计 first_byte_ms 是应用发送阶段时间，不是客户端网络测量。磁盘在响应完成后失败可能只留下 pending，重启时归类 process_interrupted。

## 官方参考（实现前已访问）

- [OpenAI Responses streaming events](https://developers.openai.com/api/reference/resources/responses/streaming-events)：采用具名事件、sequence_number 与 item/content 索引；本实现事件只表示代理已获得的文本。
- [OpenAI function calling](https://developers.openai.com/api/docs/guides/function-calling)：函数调用依赖结构化调用与结果往返。普通 respMessage 文本不足以证明工具能力。
- [Anthropic Messages API](https://platform.claude.com/docs/en/api/messages)：文本消息输出结构作为适配目标；未知 usage 不冒充精确整数。
- [Anthropic streaming](https://platform.claude.com/docs/en/build-with-claude/streaming)：采用 message 与 content_block 生命周期事件；不连接上游 SSE。

后续实测需要：可信上游 URL、经确认的整段 Cookie/CSRF、凭据更新方法、测试数据发送权限，以及目标 Claude Code 版本。只有取得结构化工具协议证据并通过多轮工具集成测试后，才应修改 Agent 支持状态。
