# Chat API Gateway

Node.js / TypeScript 文本聊天代理：将 **Cookie + CSRF、完整历史数组、全量 JSON** 上游转换为 OpenAI Chat Completions、OpenAI Responses 文本子集和 Anthropic Messages 文本接口。提供 SQLite 存档、独立管理 Key、客户端 Key 管理、统计和管理页面。

**Anthropic Messages 文本兼容，Claude Code Agent 模式不保证工作。** 工具、图片、音频和原生流式均不支持。下游 `stream=true` 等待上游完整 JSON 校验成功后才输出 SSE，不能缩短首 token 等待时间。不会向上游发送 `stream`、请求 SSE 或探测流式能力。

## 本地启动

要求 Node.js **22.13+**（使用内置 `node:sqlite`），pnpm 11.25.0。SQLite 在部分 Node 版本会输出实验性 API 提示。

```sh
pnpm install
cp .env.example .env
# 在 .env 中设置 ADMIN_API_KEY，至少 24 字符；建议使用随机值：
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
pnpm migrate
pnpm mock                 # 终端 1：127.0.0.1:3001/chat
pnpm dev                  # 终端 2：127.0.0.1:3000
```

也可使用带锁定依赖的 `npm ci && npm test && npm run build`；本项目附带 `package-lock.json`。pnpm 首次安装会生成自己的锁文件。生产运行 `pnpm build && pnpm start`。源码中的 SQL migration 与 public 目录需随 dist 一同部署，Dockerfile 已处理。

打开 `http://127.0.0.1:3000/admin`，输入管理 Key 并创建客户端 Key。明文客户端 Key **仅创建时返回一次**，数据库只存 SHA-256 摘要。将返回值设为客户端环境变量 `PROXY_API_KEY`。管理 Key 不可替代客户端 Key。

```sh
export ADMIN_API_KEY='YOUR_ADMIN_KEY'
curl -s http://127.0.0.1:3000/admin/keys \
  -H "X-Admin-Key: $ADMIN_API_KEY" -H 'Content-Type: application/json' \
  -d '{"name":"local-client"}'
export PROXY_API_KEY='KEY_RETURNED_ABOVE'
```

`.env.example` 不含真实凭据。真实部署时只修改可信的 `UPSTREAM_URL`、整段 `UPSTREAM_COOKIE` 和 `UPSTREAM_CSRF_TOKEN`。Cookie 名称需与实际抓包逐字核对；项目不假定截图中的名称正确，不实现凭据续期。不要把真实凭据提交到版本库。使用真实上游前请核实内容归档及 thought 保存权限。

## SDK 与 curl

OpenAI SDK：

```ts
import OpenAI from 'openai';
const client = new OpenAI({
  apiKey: process.env.PROXY_API_KEY,
  baseURL: 'http://127.0.0.1:3000/v1',
  maxRetries: 0, // 避免 SDK 对非幂等聊天 POST 自动重试
});
const completion = await client.chat.completions.create({
  model: 'gpt-proxy',
  messages: [{ role: 'user', content: '你好' }],
});
console.log(completion.choices[0]?.message?.content);
```

Anthropic SDK：

```ts
import Anthropic from '@anthropic-ai/sdk';
const client = new Anthropic({
  apiKey: process.env.PROXY_API_KEY,
  baseURL: 'http://127.0.0.1:3000',
  maxRetries: 0,
});
const message = await client.messages.create({
  model: 'claude-proxy',
  max_tokens: 1024,
  messages: [{ role: 'user', content: '你好' }],
});
console.log(message.content);
```

三个文本端点：

```sh
curl -s http://127.0.0.1:3000/v1/chat/completions \
  -H "Authorization: Bearer $PROXY_API_KEY" -H 'Content-Type: application/json' \
  -d '{"model":"gpt-proxy","messages":[{"role":"user","content":"你好"}]}'

curl -s http://127.0.0.1:3000/v1/responses \
  -H "Authorization: Bearer $PROXY_API_KEY" -H 'Content-Type: application/json' \
  -d '{"model":"gpt-proxy","instructions":"简短回答","input":"你好","store":true}'
# 下一次 input 只传新增内容，并携带上一次返回的 previous_response_id。

curl -N http://127.0.0.1:3000/v1/messages \
  -H "x-api-key: $PROXY_API_KEY" -H 'anthropic-version: 2023-06-01' \
  -H 'Content-Type: application/json' \
  -d '{"model":"claude-proxy","max_tokens":1024,"messages":[{"role":"user","content":"你好"}],"stream":true}'
```

管理统计、归档和导出：

```sh
curl -s http://127.0.0.1:3000/admin/stats/overview -H "X-Admin-Key: $ADMIN_API_KEY"
curl -s 'http://127.0.0.1:3000/admin/stats/timeseries?granularity=hour&limit=100' -H "X-Admin-Key: $ADMIN_API_KEY"
curl -s 'http://127.0.0.1:3000/admin/conversations?client=chat&model=gpt-proxy&limit=20&offset=0' -H "X-Admin-Key: $ADMIN_API_KEY"
curl -s 'http://127.0.0.1:3000/admin/requests?limit=20' -H "X-Admin-Key: $ADMIN_API_KEY"
export CONVERSATION_ID='conv_UUID_FROM_RESPONSE_HEADER'
curl -s "http://127.0.0.1:3000/admin/conversations/$CONVERSATION_ID/export?format=json&limit=100&offset=0" \
  -H "X-Admin-Key: $ADMIN_API_KEY" -o conversation.json
# format=md 导出 Markdown；超过一页需递增 offset 获取后续页。
```

管理接口包括 `/admin/stats/{overview,timeseries,by-key,by-model,by-protocol,by-conversation,errors}`，`/admin/keys` 的 GET/POST 和 `/admin/keys/:id` 的 DELETE（停用），`/admin/conversations/:id` 的 GET/DELETE。详见 [OpenAPI](openapi.json)。

未加密归档支持在 conversations / requests 列表使用 `q=正文片段` 搜索原始 JSON（大小写敏感，最多 200 字符），管理页面提供搜索框。加密归档不建明文搜索索引，q 请求明确返回 422；可按元数据筛选后授权导出至本地检索。

所有管理数据接口必须带 `X-Admin-Key`。静态登录页及 CSS/JS 可公开加载，无内嵌凭据或归档内容；Key 只在页面内存保存，不写 localStorage，不放 URL。管理页面包含趋势、成功率、延迟、未知 Token、会话分页、导出和删除；展示内容用 textContent，避免存档脚本注入。

## 协议与参数边界

| 功能 | 行为 |
|---|---|
| 模型 | `MODEL_ALIASES` 中的逗号分隔别名；全部调用同一个上游。未配置别名 400，绝不假装切换真实模型 |
| Chat 输入 | system/developer/user/assistant；字符串或 text blocks；`n` 仅允许 1 |
| system/developer | 带 BEGIN/END 边界标记及 JSON 转义的 user 文本上下文。上游没有已验证的原生优先级，边界不提供可靠的 prompt injection 防护 |
| Responses 输入 | 字符串或 message 项数组，text/input_text/output_text；instructions；previous_response_id；store |
| Anthropic 输入 | system 字符串/text blocks；user/assistant 文本；max_tokens 必填但无法控制上游生成长度 |
| temperature/top_p/max_tokens/max_completion_tokens/max_output_tokens | 合法类型与范围校验后忽略，响应 `X-Ignored-Parameters` 明示；不宣称采样或长度控制生效 |
| stream_options.include_usage | 不提供使用量 chunk；请求此项时在 `X-Ignored-Parameters` 标出 |
| 其他字段/blocks、tools/tool_choice、tool_result/tool_use、thinking、response_format | 422 unsupported_feature；不存在实验工具适配器，也不执行 shell 或写用户文件 |
| 上游 response | 缺失或已知 `End` 接受；未知状态 502，不猜测其他状态语义 |
| Usage | 上游已知协议没有可信数字，数据库 token_source=unknown，input/output=null；Chat/Responses usage=null；Anthropic 的 token 字段为 null（与严格 schema 的整数要求有差异）。不使用 0 冒充真实消耗 |
| 费用 | 无可信 Token/价格时 estimated_cost=null，不估算费用 |
| Headers | `X-Request-Id`、`X-Conversation-Id`、`X-Token-Source: unknown`、`X-Stream-Mode: buffered-json`；接受 Bearer 或 x-api-key；Anthropic 版本头不改变网关的固定文本子集 |

SSE：Chat 使用 completion chunks + `[DONE]`；Responses 按 created/in_progress → item/part added → text delta/done → part/item done → completed 输出，带 sequence_number；Anthropic 使用 message_start → block start/delta/stop → message_delta → message_stop。每块最多 64 个 Unicode 码点，保留 emoji，不人为延时。Fastify/Node Readable 提供下游背压。完整上游 JSON 未通过校验时始终返回普通错误 JSON，尚未发送 SSE 头。

Chat 和 Anthropic 每次按客户端完整历史确定性重建，不自行拼接旧消息。已归档的 assistant 使用“API Key + 规范化历史前缀的 SHA-256”查找真实 messageId，匹配才重放，找不到不伪造。不从其他 Key 或仅凭相同 assistant 文本寻找映射。禁用归档会停止持久化这些映射。

Responses 仅在指定 previous_response_id 时恢复本地历史；不存在、过期、不同 Key 均返回 404。store=false 不存可复用 response ID，但**独立的审计归档仍默认保存本次内容**。若想完全不保存聊天，需要 `ARCHIVE_ENABLED=false` 且 Responses 请求 `store=false`。Responses 的 instructions 在此限定子集中随历史继续保留，追加 instructions 不替换旧指令；不提供 retrieve/delete Responses API、工具或托管会话 API。

## 会话、归档与隐私

未传会话 ID 时每次生成新的 `conv_UUID`，返回 `X-Conversation-Id`；下次可携带该头关联存档。只接受本 Key 已存在的 ID；其他 Key 的 ID 返回 404。previous_response_id 默认延续原会话；与显式会话 ID 冲突返回 400。不根据文本相似度推断会话。

每个 POST `/v1/*` 有一条 requests，包括参数错误、401、429、502、504、取消等。GET 模型/健康检查和管理请求不计为模型调用。请求内容按 request_id + seq 保存一份快照，重放完整历史不额外插入第二份同轮快照；不同外部请求的历史快照会保留重复内容，以便审计每次上游输入。管理时间线按请求分组，不能把快照消息数当作用户发送次数。按调用统计只聚合 requests。

- SQLite WAL + 5 秒 busy_timeout；migration 启动自动执行，也可 `pnpm migrate`。单实例、单数据库部署，不支持多个网关进程共享数据库（启动时会将上次 pending 标记为 process_interrupted）。
- 请求开始先写审计记录，失败则拒绝转发；输入、输出及 response context 使用事务。磁盘彻底不可写时不可能保证写入审计；返回 503、记录仅含 request ID 的错误，readyz 变为 503。若故障发生在响应发送后的最终计时写入，先前 pending 记录由重启恢复标记，不能保证已发送内容撤回。
- `ARCHIVE_ENABLED=true` 默认完整存储有效输入 JSON、规范化输入、上游成功原始响应和消息。默认剔除 thoughtMessage；无效 JSON、未授权请求及上游错误原始字节不保存，错误码仍审计。敏感请求头和凭据不写库/普通日志。
- `ARCHIVE_ENABLED=false` 不保存消息内容或映射，但保留 Key ID、模型、协议、时间等统计元数据；默认仍为可关联元数据。可再启用 `ANONYMIZE_STATS=true`：完成后抹除调用记录中的 Key/会话关联，不保留 conversations，禁止 store=true、previous_response_id 及 X-Conversation-Id。此模式仍保留模型、协议、时间聚合，不再提供按 Key 分组。未启用匿名模式时 Responses store=true 仍单独保留续聊上下文。
- `ARCHIVE_RETENTION_DAYS=30`：启动和每小时清理过期内容、映射和 response contexts；调用统计元数据长期保留。启用 SQLite secure_delete，但删除不保证清除旧备份或 WAL 的全部历史字节；备份需独立设置保留期。可手动删除会话；默认保留清除内容/会话关联后的调用统计，`DELETE_STATS=true` 连同调用记录删除。删除会话会保守地清除所属 Key 的全部映射缓存，不影响其他会话正文。
- `ARCHIVE_ENCRYPTION_KEY` 为 64 位 hex，启用 AES-256-GCM 加密正文、标题、raw JSON、response contexts。字段元数据与 Key 摘要不加密。密钥独立保存、备份；更换密钥前必须离线解密再迁移，不能直接替换。此设置只加密新写入，已有明文需离线迁移/销毁。
- `SAVE_THOUGHTS` 默认 false。保存/内部重放要求加密 Key，`REPLAY_THOUGHTS=true` 还要求 SAVE_THOUGHTS。`EXPOSE_THOUGHTS=true` 仅显式将上游字段附加到非流式响应的 upstream_thought；SSE 不暴露。启用前自行核实权限。
- 查询默认近 30 天，单次时间跨度最多 366 天；limit 1–100（默认 50），offset 最大 100000。统计 p50/p95/p99 是完成请求的精确 nearest-rank，inflight 是当前进程计数。first_byte_ms 是服务端 onSend 时刻，不是网络实测首字节；latency_ms 在发送完成/连接断开时记录。

## 可靠性与部署

上游 POST 没有经过验证的幂等机制，所以**不自动重试任何聊天调用**，包括 429/5xx。客户端 SDK 也建议 maxRetries=0。用户主动重试属于新的外部请求，另计一次。每个 Key 默认每分钟 60 请求、同时 4 个；采用固定分钟窗口，进程重启清零，不是分布式限流。所有客户端输入均不能控制上游地址；重定向被拒绝。

超时默认 60 秒；客户端断连通过 AbortController 取消上游。上游请求/响应和累计续聊历史有大小上限，超限拒绝，不自动截断。错误：400 参数、401 下游鉴权、404 隔离/缺失资源、413 大小、422 能力、429 限流、502 协议/上游鉴权、503 不可用/存储、504 超时；断连记录 499。

Docker：

```sh
# 先配置 .env 中管理员 Key 和真实上游地址。
# Docker 内的 127.0.0.1 不是宿主机；本机 mock 可改为 host.docker.internal:3001
# 并使用 MOCK_HOST=0.0.0.0 pnpm mock（仅用于可信本地网络）。
docker compose up -d --build
docker compose logs --tail=50 gateway
```

容器使用 node 非 root 用户，端口仅映射宿主机回环地址，SQLite 存在命名卷 gateway-data。通过受控 HTTPS 反向代理公开服务；设置合适的请求体和读取超时（至少大于 REQUEST_TIMEOUT_MS）、关闭 SSE 响应缓冲。不要让反向代理记录 Authorization、Cookie 或正文。优雅关机先停止接单，等待在途请求；Compose 默认宽限 75 秒，修改超时配置时同步调整。

数据库文件权限 0600，进程 umask 0077，数据目录新建为 0700。推荐备份：停止网关后将整个数据卷（含 WAL/SHM）复制到受控位置，再重启；在线备份应使用 SQLite backup API/CLI `.backup`，不要只复制正在写入的主 sqlite 文件。恢复时停止网关，恢复完整备份及文件属主/权限，提供同一加密 Key 后启动验证 readyz。SQL 文件不可修改已部署迁移语义；后续 schema 变更应追加新迁移版本。

## Claude Code 与测试证据

目前没有真实上游凭据、Claude Code 安装/版本或工具能力证据；**没有任何 Claude Code 版本被标记为实测通过**。工具定义返回 422，因此 Agent 模式列为 unsupported，不提供冒充已验证的 Claude Code 启动配置。文本 Messages API 可用不等于 Claude Code 的工具和 Agent 模式可用。若后续验证目标版本，可按其官方认证配置设置 ANTHROPIC_BASE_URL、代理模型和客户端 Key，排除本机已有 Anthropic OAuth/环境变量冲突，再独立测试完整工具往返。

```sh
pnpm test               # 默认离线：mock + 官方 SDK + SQLite，不需要端口
pnpm test:network       # 包含真实 localhost TCP、首字节时序与断连测试
pnpm build
# 仅在确认可向真实上游发送测试聊天后手动运行；不在 CI 自动执行：
RUN_LIVE=true CONFIRM_LIVE_CHAT=yes pnpm test:live
```

已在当前环境执行：Node 26.8.2、macOS arm64；29 个测试通过，2 个真实 TCP 测试因 sandbox 禁止监听跳过。TypeScript build 通过。依赖由现有本地模块及 npm 缓存恢复，npm 离线 lockfile 校验成功；联网安装、Docker 构建、真实上游、Claude Code 和 CI 尚未在本环境验证。CI 配置包含 Node 22/24、网络测试和 Docker 构建。详细能力、官方参考与证据见 [COMPATIBILITY.md](COMPATIBILITY.md)。
