// Intentionally requires two explicit switches and real credentials. Never prints conversations.
import { config } from "../src/config.js";
import { callUpstream } from "../src/upstream.js";
if (process.env.RUN_LIVE !== "true" || process.env.CONFIRM_LIVE_CHAT !== "yes")
  throw Error(
    "Live test disabled; set RUN_LIVE=true CONFIRM_LIVE_CHAT=yes explicitly",
  );
const c = config();
if (!c.UPSTREAM_COOKIE || !c.UPSTREAM_CSRF_TOKEN)
  throw Error("Live credentials required");
try {
  const first = await callUpstream(
    c,
    [
      {
        role: "user",
        content: "Reply with a short greeting.",
        fileList: [],
        imageList: [],
      },
    ],
    AbortSignal.timeout(c.REQUEST_TIMEOUT_MS),
  );
  if (!first.respMessage) throw Error();
  console.log(
    "Live JSON text contract passed; tools and Claude Code remain unverified.",
  );
} catch {
  console.error(
    "Live JSON text contract failed; inspect upstream configuration privately.",
  );
  process.exitCode = 1;
}
