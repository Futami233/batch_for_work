import { config } from "../src/config.js";
import { Store } from "../src/db.js";
process.umask(0o077);
const db = new Store(config());
db.db.close();
console.log("Migration complete");
