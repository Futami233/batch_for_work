import Fastify from "fastify";
import { randomUUID } from "node:crypto";
const app = Fastify();
app.post("/chat", async (req, reply) => {
  if (!Array.isArray(req.body) || req.headers.accept !== "application/json")
    return reply.code(400).send({ error: "Expected JSON history array" });
  const last = req.body.at(-1);
  return {
    fileSendMessages: [],
    messageId: randomUUID(),
    requestTime: "",
    respMessage: `Mock reply: ${last?.content ?? ""}`,
    response: "End",
    thoughtMessage: "Mock private thought",
  };
});
await app.listen({
  host: process.env.MOCK_HOST ?? "127.0.0.1",
  port: Number(process.env.MOCK_PORT ?? 3001),
});
console.log("Mock JSON upstream listening");
