let adminKey = "",
  offset = 0;
const el = (id) => document.getElementById(id);
async function api(path, options = {}) {
  const r = await fetch(path, {
    ...options,
    headers: { "x-admin-key": adminKey, "content-type": "application/json" },
  });
  if (!r.ok) throw Error(`请求失败 (${r.status})`);
  return r.status === 204 ? null : r.json();
}
function safe(fn) {
  return async (e) => {
    e?.preventDefault();
    try {
      el("error").textContent = "";
      await fn();
    } catch (e) {
      el("error").textContent = e.message;
    }
  };
}
async function conversations() {
  const q = new URLSearchParams({ limit: "20", offset: String(offset) });
  if (el("query").value) q.set("q", el("query").value);
  if (el("model").value) q.set("model", el("model").value);
  if (el("client").value) q.set("client", el("client").value);
  const r = await api("/admin/conversations?" + q);
  el("conversations").replaceChildren();
  for (const c of r.data) {
    const li = document.createElement("li");
    const view = document.createElement("button");
    view.textContent = `${c.title || c.id} · ${c.client_type}`;
    view.onclick = safe(async () => {
      el("detail").textContent = JSON.stringify(
        await api("/admin/conversations/" + c.id),
        null,
        2,
      );
    });
    li.append(view);
    for (const format of ["json", "md"]) {
      const b = document.createElement("button");
      b.textContent = "导出 " + format;
      b.onclick = safe(async () => {
        const r = await fetch(
          `/admin/conversations/${c.id}/export?format=${format}`,
          { headers: { "x-admin-key": adminKey } },
        );
        if (!r.ok) throw Error("导出失败");
        const url = URL.createObjectURL(await r.blob());
        const a = document.createElement("a");
        a.href = url;
        a.download = `${c.id}.${format}`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      });
      li.append(b);
    }
    const del = document.createElement("button");
    del.textContent = "删除";
    del.onclick = safe(async () => {
      if (confirm("删除会话及内容？")) {
        await api("/admin/conversations/" + c.id, { method: "DELETE" });
        await conversations();
      }
    });
    li.append(del);
    el("conversations").append(li);
  }
}
async function refresh() {
  el("overview").textContent = JSON.stringify(
    await api("/admin/stats/overview"),
    null,
    2,
  );
  const trend = await api("/admin/stats/timeseries");
  el("trend").replaceChildren();
  for (const r of trend.data) {
    const tr = document.createElement("tr");
    for (const v of [
      r.bucket,
      `调用 ${r.calls}`,
      `成功 ${r.success}`,
      `失败 ${r.failed}`,
    ]) {
      const td = document.createElement("td");
      td.textContent = v;
      tr.append(td);
    }
    el("trend").append(tr);
  }
  await conversations();
  el("keys").replaceChildren();
  for (const k of (await api("/admin/keys")).data) {
    const li = document.createElement("li");
    li.textContent = `${k.name} (${k.status}) `;
    const b = document.createElement("button");
    b.textContent = "停用";
    b.onclick = safe(async () => {
      await api("/admin/keys/" + k.id, { method: "DELETE" });
      await refresh();
    });
    li.append(b);
    el("keys").append(li);
  }
}
el("login").onsubmit = safe(async () => {
  adminKey = el("key").value;
  el("key").value = "";
  await refresh();
});
el("create").onsubmit = safe(async () => {
  el("newkey").textContent = JSON.stringify(
    await api("/admin/keys", {
      method: "POST",
      body: JSON.stringify({ name: el("name").value }),
    }),
    null,
    2,
  );
  await refresh();
});
el("search").onclick = safe(async () => {
  offset = 0;
  await conversations();
});
el("next").onclick = safe(async () => {
  offset += 20;
  await conversations();
});
el("prev").onclick = safe(async () => {
  offset = Math.max(0, offset - 20);
  await conversations();
});
