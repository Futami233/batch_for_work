import { describe, expect, it } from "vitest";
import { mkdtempSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Store } from "../src/db.js";
import { config } from "../src/config.js";
describe("durable store", () => {
  it("persists contexts, protects files, and recovers pending requests after restart", () => {
    const dir = mkdtempSync(join(tmpdir(), "gateway-test-"));
    const c = config({
      ADMIN_API_KEY: "test-admin-key-at-least-24-chars",
      DATABASE_URL: join(dir, "db.sqlite"),
      ARCHIVE_ENCRYPTION_KEY: "ab".repeat(32),
    });
    let db: Store | undefined;
    try {
      db = new Store(c);
      const context = [{ role: "user", content: "private text" }];
      db.run(
        "INSERT INTO response_contexts VALUES(?,?,?,?,?)",
        "resp_test",
        "key",
        "conv",
        db.encode(context),
        Date.now(),
      );
      db.run(
        "INSERT INTO requests(id,status,started_at) VALUES(?,?,?)",
        "request",
        "pending",
        Date.now(),
      );
      expect(Number(db.get("PRAGMA busy_timeout")!.timeout)).toBe(5000);
      expect(db.get("PRAGMA journal_mode")!.journal_mode).toBe("wal");
      expect(statSync(c.DATABASE_URL).mode & 0o777).toBe(0o600);
      db.db.close();
      db = new Store(c);
      expect(
        db.decode(
          db.get("SELECT history_json FROM response_contexts")!.history_json,
        ),
      ).toEqual(context);
      expect(db.get("SELECT status,error_code FROM requests")).toEqual({
        status: "failed",
        error_code: "process_interrupted",
      });
      expect(db.get("SELECT COUNT(*) n FROM schema_migrations")!.n).toBe(1);
    } finally {
      db?.db.close();
      rmSync(dir, { recursive: true, force: true });
    }
  });
  it("rolls back an entire transaction and detects ciphertext tampering", () => {
    const db = new Store(
      config({
        ADMIN_API_KEY: "test-admin-key-at-least-24-chars",
        DATABASE_URL: ":memory:",
        ARCHIVE_ENCRYPTION_KEY: "ab".repeat(32),
      }),
    );
    try {
      expect(() =>
        db.transaction(() => {
          db.run(
            "INSERT INTO requests(id,status,started_at) VALUES(?,?,?)",
            "x",
            "pending",
            0,
          );
          throw Error("failure");
        }),
      ).toThrow();
      expect(db.get("SELECT COUNT(*) n FROM requests")!.n).toBe(0);
      const encoded = db.encode("secret");
      const fields = encoded.split(":");
      fields[3] = Buffer.alloc(16).toString("base64");
      expect(() => db.decode(fields.join(":"))).toThrow();
    } finally {
      db.db.close();
    }
  });
});
