import { afterEach, describe, expect, it } from "vitest";
import Fastify from "fastify";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import fixture from "./fixtures/upstream.json";
import { createServer, request } from "node:http";
import { config } from "../src/config.js";
import { createApp } from "../src/app.js";
import { upstreamHistory } from "../src/normalize.js";
const admin = "test-admin-secret-at-least-24-characters";
const network = process.env.TEST_NETWORK === "true";
function injectionFetch(app: any): typeof fetch {
  return (async (input: any, init: any = {}) => {
    if (init.signal?.aborted) throw Error("aborted");
    let abort: () => void = () => {};
    const cancelled = new Promise<never>((_, reject) => {
      abort = () => reject(Error("aborted"));
      init.signal?.addEventListener("abort", abort, { once: true });
    });
    try {
      const result = await Promise.race([
        app.inject({
          method: init.method ?? "GET",
          url: new URL(String(input)).pathname,
          headers: Object.fromEntries(new Headers(init.headers)),
          payload: init.body,
        }),
        cancelled,
      ]);
      return new Response(result.body, {
        status: result.statusCode,
        headers: result.headers,
      });
    } finally {
      init.signal?.removeEventListener("abort", abort);
    }
  }) as typeof fetch;
}
const closers: (() => Promise<any>)[] = [];
afterEach(async () => {
  for (const f of closers.splice(0).reverse()) await f();
});
async function setup(
  overrides: Record<string, unknown> = {},
  handler?: any,
  transport?: typeof fetch,
) {
  const seen: any[] = [];
  const upstream = Fastify();
  upstream.post(
    "/chat",
    handler ??
      (async (req: any) => {
        seen.push({ body: req.body, headers: req.headers });
        return {
          respMessage: fixture.respMessage,
          messageId: "upstream-id",
          thoughtMessage: "private-thought",
          response: "End",
          fileSendMessages: [],
        };
      }),
  );
  if (network) await upstream.listen({ host: "127.0.0.1", port: 0 });
  else await upstream.ready();
  closers.push(() => upstream.close());
  const upstreamURL =
    (network ? upstream.listeningOrigin : "http://mock-upstream") + "/chat";
  const c = config({
    ADMIN_API_KEY: admin,
    DATABASE_URL: ":memory:",
    UPSTREAM_URL: upstreamURL,
    ...overrides,
  });
  const { app, db } = createApp(
    c,
    transport ?? (network ? fetch : injectionFetch(upstream)),
  );
  if (network) await app.listen({ host: "127.0.0.1", port: 0 });
  else await app.ready();
  closers.push(() => app.close());
  const makeKey = async (name = "test") =>
    (
      await app.inject({
        method: "POST",
        url: "/admin/keys",
        headers: { "x-admin-key": admin },
        payload: { name },
      })
    ).json();
  const key = (await makeKey()).key;
  const headers = { authorization: "Bearer " + key };
  const post = (url: string, payload: any, h: Record<string, string> = {}) =>
    app.inject({ method: "POST", url, headers: { ...headers, ...h }, payload });
  const get = (url: string) =>
    app.inject({ url, headers: { "x-admin-key": admin } });
  return {
    app,
    db,
    seen,
    c,
    key,
    headers,
    post,
    get,
    makeKey,
    fetch: network ? fetch : injectionFetch(app),
    url: network ? app.listeningOrigin : "http://gateway",
  };
}
const chat = {
  model: "gpt-proxy",
  messages: [{ role: "user", content: "你好" }],
};
describe("official SDK text contracts", () => {
  it("OpenAI chat multi-turn and buffered SSE", async () => {
    const s = await setup();
    const client = new OpenAI({
      apiKey: s.key,
      baseURL: s.url + "/v1",
      maxRetries: 0,
      fetch: s.fetch,
    });
    const one = await client.chat.completions.create(chat as any);
    expect(one.choices[0]?.message.content).toBe("你好 🌏");
    expect(one.usage).toBeNull();
    let text = "";
    const stream = await client.chat.completions.create({
      ...chat,
      messages: [
        ...chat.messages,
        { role: "assistant", content: "你好 🌏" },
        { role: "user", content: "继续" },
      ],
      stream: true,
    } as any);
    for await (const event of stream as any)
      text += event.choices[0]?.delta.content ?? "";
    expect(text).toBe("你好 🌏");
    expect(s.seen[1].body[1].messageId).toBe("upstream-id");
    expect(s.seen[1].body[1]).not.toHaveProperty("thoughtContent");
    for (const call of s.seen) {
      expect(Array.isArray(call.body)).toBe(true);
      expect(call.headers.accept).toBe("application/json");
      expect(JSON.stringify(call.body)).not.toContain('"stream"');
    }
    expect(s.db.get("SELECT COUNT(*) n FROM requests")?.n).toBe(2);
  });
  it("Anthropic SDK multi-turn and stream events", async () => {
    const s = await setup();
    const client = new Anthropic({
      apiKey: s.key,
      baseURL: s.url,
      maxRetries: 0,
      fetch: s.fetch,
    });
    const first = await client.messages.create({
      model: "claude-proxy",
      max_tokens: 100,
      messages: [{ role: "user", content: "你好" }],
    });
    expect(first.content).toEqual([{ type: "text", text: "你好 🌏" }]);
    const stream = await client.messages.create({
      model: "claude-proxy",
      max_tokens: 100,
      messages: [
        { role: "user", content: "你好" },
        { role: "assistant", content: first.content },
        { role: "user", content: "继续" },
      ],
      stream: true,
    });
    const events = [];
    for await (const e of stream) events.push(e);
    expect(events.map((e) => e.type)).toEqual([
      "message_start",
      "content_block_start",
      "content_block_delta",
      "content_block_stop",
      "message_delta",
      "message_stop",
    ]);
    expect(s.seen[1].body[1].messageId).toBe("upstream-id");
  });
  it("Responses SDK continuation, events, isolation, store=false", async () => {
    const s = await setup();
    const client = new OpenAI({
      apiKey: s.key,
      baseURL: s.url + "/v1",
      maxRetries: 0,
      fetch: s.fetch,
    });
    const first = await client.responses.create({
      model: "gpt-proxy",
      input: "你好",
    });
    expect(first.output_text).toBe("你好 🌏");
    const stream = await client.responses.create({
      model: "gpt-proxy",
      input: "继续",
      previous_response_id: first.id,
      stream: true,
    });
    const events = [];
    for await (const e of stream) events.push(e);
    expect(events.map((e) => e.type)).toEqual([
      "response.created",
      "response.in_progress",
      "response.output_item.added",
      "response.content_part.added",
      "response.output_text.delta",
      "response.output_text.done",
      "response.content_part.done",
      "response.output_item.done",
      "response.completed",
    ]);
    expect(events.map((e) => (e as any).sequence_number)).toEqual([
      0, 1, 2, 3, 4, 5, 6, 7, 8,
    ]);
    expect(s.seen[1].body).toHaveLength(3);
    expect(s.seen[1].body[1].messageId).toBe("upstream-id");
    const secondKey = (await s.makeKey("other")).key;
    expect(
      (
        await s.post(
          "/v1/responses",
          { model: "gpt-proxy", input: "x", previous_response_id: first.id },
          { authorization: "Bearer " + secondKey },
        )
      ).statusCode,
    ).toBe(404);
    const noStore = await client.responses.create({
      model: "gpt-proxy",
      input: "x",
      store: false,
    });
    expect(
      (
        await s.post("/v1/responses", {
          model: "gpt-proxy",
          input: "x",
          previous_response_id: noStore.id,
        })
      ).statusCode,
    ).toBe(404);
    expect(s.db.get("SELECT COUNT(*) n FROM messages")!.n).toBeGreaterThan(0);
  });
});
describe("validation and security", () => {
  it("preserves boundaries and known assistant mapping", () => {
    const history = upstreamHistory(
      [
        { role: "system", content: "instruction" },
        { role: "user", content: "question" },
        { role: "assistant", content: "answer" },
      ],
      () => ({ messageId: "id", thoughtContent: "thought" }),
    );
    expect(history[0]?.content).toContain("BEGIN DOWNGRADED SYSTEM");
    expect(history[1]).toEqual({
      role: "user",
      content: "question",
      fileList: [],
      imageList: [],
    });
    expect(history[2]).toEqual({
      role: "assistant",
      content: "answer",
      messageId: "id",
      thoughtContent: "thought",
    });
  });
  it("rejects tools, images, unknown params, bad model, malformed bodies; audits once", async () => {
    const s = await setup();
    for (const body of [
      { ...chat, tools: [] },
      {
        ...chat,
        messages: [
          {
            role: "user",
            content: [{ type: "image_url", image_url: { url: "x" } }],
          },
        ],
      },
      { ...chat, seed: 1 },
      { ...chat, model: "not-real" },
    ])
      expect(
        (await s.post("/v1/chat/completions", body)).statusCode,
      ).toBeGreaterThanOrEqual(400);
    const bad = await s.app.inject({
      method: "POST",
      url: "/v1/messages",
      headers: { ...s.headers, "content-type": "application/json" },
      payload: "{",
    });
    expect(bad.statusCode).toBe(400);
    const unauth = await s.app.inject({
      method: "POST",
      url: "/v1/chat/completions",
      payload: chat,
    });
    expect(unauth.statusCode).toBe(401);
    expect(s.db.get("SELECT COUNT(*) n FROM requests")!.n).toBe(6);
    expect(s.seen).toHaveLength(0);
    expect(
      (await s.app.inject({ url: "/admin/keys", headers: s.headers }))
        .statusCode,
    ).toBe(401);
    expect(s.db.get("SELECT key_hash FROM api_keys")!.key_hash).not.toBe(s.key);
  });
  it("archive encryption and private thought replay require opt-in", async () => {
    const s = await setup({
      ARCHIVE_ENCRYPTION_KEY: "a".repeat(64),
      SAVE_THOUGHTS: "true",
      REPLAY_THOUGHTS: "true",
    });
    const first = await s.post("/v1/chat/completions", chat);
    expect(first.body).not.toContain("private-thought");
    await s.post("/v1/chat/completions", {
      ...chat,
      messages: [
        ...chat.messages,
        { role: "assistant", content: "你好 🌏" },
        { role: "user", content: "again" },
      ],
    });
    expect(s.seen[1].body[1].thoughtContent).toBe("private-thought");
    const raw = s.db.get(
      "SELECT upstream_response_json FROM requests",
    )!.upstream_response_json;
    expect(raw).toMatch(/^enc:/);
    expect(raw).not.toContain("private-thought");
    expect(s.db.decode(raw).thoughtMessage).toBe("private-thought");
  });
  it("privacy mode disables content archive; independent Responses store policy", async () => {
    const s = await setup({ ARCHIVE_ENABLED: "false" });
    await s.post("/v1/chat/completions", chat);
    await s.post("/v1/responses", {
      model: "gpt-proxy",
      input: "x",
      store: false,
    });
    expect(s.db.get("SELECT COUNT(*) n FROM messages")!.n).toBe(0);
    expect(s.db.get("SELECT COUNT(*) n FROM response_contexts")!.n).toBe(0);
    expect(
      s.db
        .all(
          "SELECT upstream_request_json,external_request_json,upstream_response_json FROM requests",
        )
        .every((r) => Object.values(r).every((v) => v === null)),
    ).toBe(true);
  });
  it("limits body and context, rpm, concurrent calls", async () => {
    const s = await setup({ MAX_BODY_BYTES: 150, RATE_LIMIT_RPM: 1 });
    expect(
      (
        await s.post("/v1/chat/completions", {
          ...chat,
          messages: [{ role: "user", content: "x".repeat(300) }],
        })
      ).statusCode,
    ).toBe(413);
    expect((await s.post("/v1/chat/completions", chat)).statusCode).toBe(429);
    expect(s.db.get("SELECT COUNT(*) n FROM requests")!.n).toBe(2);
  });
});
describe("upstream error contracts", () => {
  it.each(["chat", "responses", "anthropic"])(
    "buffers complete upstream JSON before %s SSE",
    async (protocol) => {
      let finish!: () => void;
      let entered!: () => void;
      const started = new Promise<void>((r) => (entered = r));
      const transport = (async () =>
        new Response(
          new ReadableStream({
            start(controller) {
              controller.enqueue(
                new TextEncoder().encode('{"respMessage":"buffered'),
              );
              finish = () => {
                controller.enqueue(
                  new TextEncoder().encode('","response":"End"}'),
                );
                controller.close();
              };
              entered();
            },
          }),
          { headers: { "content-type": "application/json" } },
        )) as typeof fetch;
      const s = await setup({}, undefined, transport);
      let settled = false;
      const path =
        protocol === "chat"
          ? "/v1/chat/completions"
          : protocol === "responses"
            ? "/v1/responses"
            : "/v1/messages";
      const body =
        protocol === "responses"
          ? { model: "gpt-proxy", input: "hello", stream: true }
          : { ...chat, max_tokens: 10, stream: true };
      const pending = s.post(path, body).then((r) => {
        settled = true;
        return r;
      });
      await started;
      await new Promise((r) => setTimeout(r, 5));
      expect(settled).toBe(false);
      finish();
      const result = await pending;
      expect(result.statusCode).toBe(200);
      expect(result.headers["content-type"]).toContain("text/event-stream");
      expect(result.body).toContain("buffered");
    },
  );
  it.each([
    [401, 502, "upstream_auth_error"],
    [403, 502, "upstream_auth_error"],
    [429, 429, "upstream_rate_limited"],
    [500, 503, "upstream_http_error"],
  ])("maps %i without retry", async (status, expected, code) => {
    let calls = 0;
    const s = await setup({}, async (_req: any, reply: any) => {
      calls++;
      return reply.code(status as number).send({ secret: "never expose" });
    });
    const r = await s.post("/v1/chat/completions", { ...chat, stream: true });
    expect(r.statusCode).toBe(expected);
    expect(r.json().error.code).toBe(code);
    expect(r.body).not.toContain("secret");
    expect(calls).toBe(1);
    expect(s.db.get("SELECT COUNT(*) n FROM requests")!.n).toBe(1);
  });
  it.each(["sse", "html", "json", "empty", "state"])(
    "rejects invalid %s before SSE headers",
    async (mode) => {
      const s = await setup({}, async (_req: any, reply: any) =>
        mode === "sse"
          ? reply.type("text/event-stream").send("data: bad\n\n")
          : mode === "html"
            ? reply.type("text/html").send("secret")
            : mode === "json"
              ? reply.type("application/json").send("{")
              : mode === "empty"
                ? { respMessage: "" }
                : { respMessage: "hi", response: "Unknown" },
      );
      const r = await s.post("/v1/chat/completions", { ...chat, stream: true });
      expect(r.statusCode).toBe(502);
      expect(r.headers["content-type"]).toContain("application/json");
    },
  );
  it("timeouts are counted exactly once", async () => {
    const s = await setup({ REQUEST_TIMEOUT_MS: 20 }, async () => {
      await new Promise((r) => setTimeout(r, 80));
      return { respMessage: "late" };
    });
    expect(
      (
        await s.post("/v1/messages", {
          model: "claude-proxy",
          max_tokens: 10,
          messages: chat.messages,
          stream: true,
        })
      ).statusCode,
    ).toBe(504);
    expect(s.db.get("SELECT status,error_code FROM requests")).toEqual({
      status: "failed",
      error_code: "upstream_timeout",
    });
  });
  it.skipIf(!network)(
    "never sends downstream bytes before upstream completes JSON",
    async () => {
      let complete = false;
      const up = createServer((_req, res) => {
        res.setHeader("content-type", "application/json");
        res.write('{"respMessage":"hello');
        setTimeout(() => {
          complete = true;
          res.end('","response":"End"}');
        }, 60);
      });
      await new Promise<void>((r) => up.listen(0, "127.0.0.1", r));
      closers.push(() => new Promise<void>((r) => up.close(() => r())));
      const s = await setup({
        UPSTREAM_URL: `http://127.0.0.1:${(up.address() as any).port}`,
      });
      const r = await fetch(s.url + "/v1/responses", {
        method: "POST",
        headers: { ...s.headers, "content-type": "application/json" },
        body: JSON.stringify({
          model: "gpt-proxy",
          input: "hello",
          stream: true,
        }),
      });
      expect(complete).toBe(true);
      expect(await r.text()).toContain("response.completed");
    },
  );
  it.skipIf(!network)(
    "client disconnect aborts work and releases concurrency",
    async () => {
      let begun!: () => void;
      const started = new Promise<void>((r) => (begun = r));
      const s = await setup({}, async () => {
        begun();
        await new Promise((r) => setTimeout(r, 100));
        return { respMessage: "late" };
      });
      const req = request(s.url + "/v1/chat/completions", {
        method: "POST",
        headers: { ...s.headers, "content-type": "application/json" },
      });
      req.on("error", () => {});
      req.end(JSON.stringify(chat));
      await started;
      req.destroy();
      await new Promise((r) => setTimeout(r, 40));
      expect(
        s.db.get("SELECT status,client_disconnected FROM requests"),
      ).toEqual({ status: "cancelled", client_disconnected: 1 });
      expect((await s.get("/admin/stats/overview")).json().inflight).toBe(0);
    },
  );
  it("concurrent requests respect limit and remain separate", async () => {
    const s = await setup({ KEY_CONCURRENCY: 1 }, async () => {
      await new Promise((r) => setTimeout(r, 40));
      return { respMessage: "ok" };
    });
    const result = await Promise.all([
      s.post("/v1/chat/completions", chat),
      s.post("/v1/chat/completions", chat),
    ]);
    expect(result.map((r) => r.statusCode).sort()).toEqual([200, 429]);
    expect(s.db.get("SELECT COUNT(*) n FROM requests")!.n).toBe(2);
  });
  it("disk write failure fails closed before upstream", async () => {
    const s = await setup();
    s.db.db.exec(
      "CREATE TRIGGER fail_requests BEFORE INSERT ON requests BEGIN SELECT RAISE(ABORT, 'disk full'); END",
    );
    const r = await s.post("/v1/chat/completions", chat);
    expect(r.statusCode).toBe(503);
    expect(s.seen).toHaveLength(0);
    expect((await s.app.inject("/readyz")).statusCode).toBe(503);
  });
});
describe("archive and management", () => {
  it("anonymous privacy mode retains aggregate counts without key or conversation linkage", async () => {
    const s = await setup({
      ARCHIVE_ENABLED: "false",
      ANONYMIZE_STATS: "true",
    });
    expect((await s.post("/v1/chat/completions", chat)).statusCode).toBe(200);
    expect(
      (await s.post("/v1/responses", { model: "gpt-proxy", input: "hello" }))
        .statusCode,
    ).toBe(422);
    expect(s.db.get("SELECT COUNT(*) n FROM conversations")!.n).toBe(0);
    expect(
      s.db
        .all(
          "SELECT api_key_id,conversation_id,external_request_json FROM requests",
        )
        .every((r) => Object.values(r).every((v) => v === null)),
    ).toBe(true);
    expect((await s.get("/admin/stats/overview")).json().calls).toBe(2);
  });
  it("searches authorized raw archive text and refuses encrypted text indexing", async () => {
    const s = await setup();
    await s.post("/v1/chat/completions", chat);
    expect(
      (
        await s.get("/admin/conversations?q=" + encodeURIComponent("你好"))
      ).json().data,
    ).toHaveLength(1);
    expect((await s.get("/admin/requests?q=missing")).json().data).toHaveLength(
      0,
    );
    const encrypted = await setup({ ARCHIVE_ENCRYPTION_KEY: "a".repeat(64) });
    expect(
      (await encrypted.get("/admin/conversations?q=hello")).statusCode,
    ).toBe(422);
  });

  it("conversation isolation, pagination, exports, statistics and deletion", async () => {
    const s = await setup();
    const first = await s.post("/v1/chat/completions", chat);
    const id = first.headers["x-conversation-id"] as string;
    await s.post(
      "/v1/chat/completions",
      {
        ...chat,
        messages: [
          ...chat.messages,
          { role: "assistant", content: "你好 🌏" },
          { role: "user", content: "next" },
        ],
      },
      { "x-conversation-id": id },
    );
    expect(s.db.get("SELECT COUNT(*) n FROM conversations")!.n).toBe(1);
    expect(s.db.get("SELECT COUNT(*) n FROM messages")!.n).toBe(6);
    const other = (await s.makeKey()).key;
    expect(
      (
        await s.post("/v1/chat/completions", chat, {
          "x-conversation-id": id,
          authorization: "Bearer " + other,
        })
      ).statusCode,
    ).toBe(404);
    const detail = (
      await s.get("/admin/conversations/" + id + "?limit=1")
    ).json();
    expect(detail.requests).toHaveLength(1);
    expect(detail.messages).toHaveLength(2);
    expect(
      (await s.get("/admin/conversations/" + id + "/export?format=md")).body,
    ).toContain("你好");
    const stats = (await s.get("/admin/stats/overview")).json();
    expect(stats.calls).toBe(3);
    expect(stats.success).toBe(2);
    expect(stats.failed).toBe(1);
    expect(stats.input_tokens).toBeNull();
    for (const name of [
      "timeseries",
      "by-key",
      "by-model",
      "by-protocol",
      "by-conversation",
      "errors",
    ])
      expect((await s.get("/admin/stats/" + name)).statusCode).toBe(200);
    expect((await s.get("/admin/conversations?limit=10000")).statusCode).toBe(
      400,
    );
    await s.app.inject({
      method: "DELETE",
      url: "/admin/conversations/" + id,
      headers: { "x-admin-key": admin },
    });
    expect(s.db.get("SELECT COUNT(*) n FROM messages")!.n).toBe(0);
    expect(s.db.get("SELECT COUNT(*) n FROM requests")!.n).toBe(3);
  });
  it("retention removes contents, reusable contexts and mappings", async () => {
    const s = await setup();
    await s.post("/v1/responses", { model: "gpt-proxy", input: "x" });
    for (const table of [
      "messages",
      "response_contexts",
      "message_mappings",
      "conversations",
    ])
      s.db.run(
        `UPDATE ${table} SET ${table === "conversations" ? "updated_at" : "created_at"}=0`,
      );
    s.db.run("UPDATE requests SET started_at=0");
    s.db.purge();
    expect(s.db.get("SELECT COUNT(*) n FROM messages")!.n).toBe(0);
    expect(s.db.get("SELECT COUNT(*) n FROM response_contexts")!.n).toBe(0);
    expect(
      s.db.get("SELECT upstream_response_json FROM requests")!
        .upstream_response_json,
    ).toBeNull();
  });
});
