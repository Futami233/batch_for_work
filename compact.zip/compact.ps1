param(
    [Parameter(Mandatory = $true)]
    [string]$PartsDir,

    [Parameter(Mandatory = $true)]
    [string]$OutDir,

    [int]$CanvasWidth = 3200,
    [int]$CanvasHeight = 1400,
    [int]$LeftGutterWidth = 90,
    [int]$TopBarHeight = 36,
    [int]$TabBarHeight = 40,
    [int]$EditorPadding = 24,
    [int]$CellWidth = 10,
    [int]$CellHeight = 16,
    [int]$Cols = 320,
    [int]$Rows = 80
)


$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

function Ensure-Dir {
    param([string]$Path)
    if (!(Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path | Out-Null
    }
}

function Get-Sha256 {
    param([string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower()
}

function Get-Bytes {
    param([string]$Path)
    return [System.IO.File]::ReadAllBytes($Path)
}

function Bytes-To-Bits {
    param([byte[]]$Bytes)
    $bits = New-Object System.Collections.Generic.List[byte]
    foreach ($b in $Bytes) {
        for ($i = 7; $i -ge 0; $i--) {
            [void]$bits.Add([byte](($b -shr $i) -band 1))
        }
    }
    return ,$bits.ToArray()
}

function Get-FakeCodeLines {
    param(
        [string]$PartName,
        [string]$Sha256,
        [int]$Count
    )

    $seedA = $PartName.Replace(".","_")
    $seedB = $Sha256.Substring(0, 12)

    $templates = @(
        'import { readFileSync } from "fs";',
        'const worker = createWorkerPool(config);',
        'async function processChunk(input, state) {',
        '  const result = await pipeline.run(task);',
        '  if (!context || !context.enabled) return null;',
        '  const checksum = computeHash(buffer);',
        '  logger.info("processing started");',
        '  logger.warn("retrying transient failure");',
        '  const normalized = normalizePath(filePath);',
        '  const payload = encodeFrame(chunkIndex, totalChunks);',
        '  const meta = { file: name, size: size };',
        '  const current = items[index] ?? defaultValue;',
        '  for (let i = 0; i < retries; i++) {',
        '  return await executePlan(plan, signal);',
        '  const cacheKey = `${kind}:${id}:${rev}`;',
        '  const frameId = `${session}-${sequence}`;',
        '  const token = source.slice(offset, offset + size);',
        '  const output = transform(input, options);',
        '  if (error) throw new Error(message);',
        '  await writeArtifact(targetPath, content);',
        '  const manifest = await loadManifest(rootDir);',
        '  const stats = summarize(results, options);',
        '  state.lastUpdatedAt = new Date().toISOString();',
        '  return { ok: true, value: result };',
        '  // sync editor decorations',
        '  // preserve source mapping metadata',
        '  // fallback branch for partial decode',
        '  // NOTE: frame payload continues below',
        '  const channel = "stable";',
        '  const sessionId = "' + $seedB + '";',
        '  const sourceName = "' + $seedA + '";',
        '  const featureFlags = ["fast-path", "safe-io"];',
        '  const threshold = 0.875;',
        '  const viewport = { width: 3200, height: 1400 };',
        '  const decoderState = createStateMachine();',
        '  const transport = new VisualTransportEncoder();',
        '  const artifact = await archiveDirectory(inputDir);',
        '  const chunkTable = buildChunkTable(artifact);',
        '  const theme = "dark-modern";',
        '  export async function runJob(args) {',
        '}',
        '',
        'type FrameMeta = {',
        '  partName: string;',
        '  sha256: string;',
        '  createdAt: string;',
        '};'
    )

    $lines = New-Object System.Collections.Generic.List[string]
    for ($i = 0; $i -lt $Count; $i++) {
        [void]$lines.Add($templates[$i % $templates.Count])
    }
    return ,$lines.ToArray()
}

function Draw-StringSafe {
    param(
        [System.Drawing.Graphics]$G,
        [string]$Text,
        [System.Drawing.Font]$Font,
        [System.Drawing.Brush]$Brush,
        [float]$X,
        [float]$Y
    )
    $G.DrawString($Text, $Font, $Brush, $X, $Y)
}

function Render-PartFrame {
    param(
        [string]$PartPath,
        [string]$OutPng,
        [int]$CanvasWidth,
        [int]$CanvasHeight,
        [int]$LeftGutterWidth,
        [int]$TopBarHeight,
        [int]$TabBarHeight,
        [int]$EditorPadding,
        [int]$CellWidth,
        [int]$CellHeight,
        [int]$Cols,
        [int]$Rows,
        [int]$Index,
        [int]$Total
    )

    $bytes = Get-Bytes $PartPath
    $sha256 = Get-Sha256 $PartPath
    $bits = Bytes-To-Bits $bytes
    $partName = [System.IO.Path]::GetFileName($PartPath)
    $fileSize = (Get-Item -LiteralPath $PartPath).Length

    $capacityBits = $Cols * $Rows
    if ($bits.Length -gt $capacityBits) {
        throw "分片过大：$partName 需要 $($bits.Length) bits，但当前画布只能容纳 $capacityBits bits。请减小 PartSizeMB 或增大 Cols/Rows。"
    }

    $bmp = New-Object System.Drawing.Bitmap($CanvasWidth, $CanvasHeight, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)

    try {
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighSpeed
        $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit
        $g.Clear([System.Drawing.Color]::FromArgb(30, 30, 30))

        # Colors
        $bgTitle = [System.Drawing.Color]::FromArgb(24, 24, 24)
        $bgTab = [System.Drawing.Color]::FromArgb(37, 37, 38)
        $bgEditor = [System.Drawing.Color]::FromArgb(30, 30, 30)
        $bgActiveTab = [System.Drawing.Color]::FromArgb(45, 45, 48)
        $bgSidebar = [System.Drawing.Color]::FromArgb(37, 37, 38)
        $lineNumberColor = [System.Drawing.Color]::FromArgb(110, 110, 110)
        $textColor = [System.Drawing.Color]::FromArgb(212, 212, 212)
        $keywordColor = [System.Drawing.Color]::FromArgb(86, 156, 214)
        $stringColor = [System.Drawing.Color]::FromArgb(206, 145, 120)
        $commentColor = [System.Drawing.Color]::FromArgb(106, 153, 85)
        $accentColor = [System.Drawing.Color]::FromArgb(0, 122, 204)
        $bit0Color = [System.Drawing.Color]::FromArgb(42, 42, 42)
        $bit1Color = [System.Drawing.Color]::FromArgb(62, 62, 62)
        $bitBorder = [System.Drawing.Color]::FromArgb(48, 48, 48)
        $cursorColor = [System.Drawing.Color]::FromArgb(174, 174, 174)

        $brushTitle = New-Object System.Drawing.SolidBrush($bgTitle)
        $brushTab = New-Object System.Drawing.SolidBrush($bgTab)
        $brushEditor = New-Object System.Drawing.SolidBrush($bgEditor)
        $brushActiveTab = New-Object System.Drawing.SolidBrush($bgActiveTab)
        $brushSidebar = New-Object System.Drawing.SolidBrush($bgSidebar)
        $brushLineNumber = New-Object System.Drawing.SolidBrush($lineNumberColor)
        $brushText = New-Object System.Drawing.SolidBrush($textColor)
        $brushKeyword = New-Object System.Drawing.SolidBrush($keywordColor)
        $brushString = New-Object System.Drawing.SolidBrush($stringColor)
        $brushComment = New-Object System.Drawing.SolidBrush($commentColor)
        $brushAccent = New-Object System.Drawing.SolidBrush($accentColor)
        $brushBit0 = New-Object System.Drawing.SolidBrush($bit0Color)
        $brushBit1 = New-Object System.Drawing.SolidBrush($bit1Color)
        $penBitBorder = New-Object System.Drawing.Pen($bitBorder, 1)

        $fontUi = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Regular)
        $fontUiBold = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
        $fontCode = New-Object System.Drawing.Font("Consolas", 12, [System.Drawing.FontStyle]::Regular)
        $fontCodeSmall = New-Object System.Drawing.Font("Consolas", 11, [System.Drawing.FontStyle]::Regular)

        # Layout
        $editorTop = $TopBarHeight + $TabBarHeight
        $editorHeight = $CanvasHeight - $editorTop
        $codeStartX = $LeftGutterWidth + $EditorPadding
        $codeStartY = $editorTop + $EditorPadding

        # Bars
        $g.FillRectangle($brushTitle, 0, 0, $CanvasWidth, $TopBarHeight)
        $g.FillRectangle($brushTab, 0, $TopBarHeight, $CanvasWidth, $TabBarHeight)
        $g.FillRectangle($brushSidebar, 0, $editorTop, $LeftGutterWidth, $editorHeight)
        $g.FillRectangle($brushEditor, $LeftGutterWidth, $editorTop, $CanvasWidth - $LeftGutterWidth, $editorHeight)

        # Top bar dots
        $g.FillEllipse((New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255,95,86))), 14, 10, 14, 14)
        $g.FillEllipse((New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255,189,46))), 36, 10, 14, 14)
        $g.FillEllipse((New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(39,201,63))), 58, 10, 14, 14)

        Draw-StringSafe -G $g -Text "Visual Studio Code" -Font $fontUi -Brush $brushText -X 120 -Y 8

        # Active tab
        $tabX = 120
        $tabY = $TopBarHeight + 4
        $tabW = 420
        $tabH = $TabBarHeight - 6
        $g.FillRectangle($brushActiveTab, $tabX, $tabY, $tabW, $tabH)
        $g.FillRectangle($brushAccent, $tabX, $TopBarHeight + $TabBarHeight - 3, $tabW, 3)
        Draw-StringSafe -G $g -Text $partName -Font $fontUi -Brush $brushText -X ($tabX + 16) -Y ($tabY + 8)

        # Meta top right
        Draw-StringSafe -G $g -Text ("Part {0}/{1}" -f $Index, $Total) -Font $fontUi -Brush $brushText -X ($CanvasWidth - 240) -Y 8
        Draw-StringSafe -G $g -Text ("{0} bytes" -f $fileSize) -Font $fontUi -Brush $brushText -X ($CanvasWidth - 240) -Y 28

        $fakeLines = Get-FakeCodeLines -PartName $partName -Sha256 $sha256 -Count $Rows

        $bitIndex = 0
        for ($row = 0; $row -lt $Rows; $row++) {
            $y = $codeStartY + ($row * $CellHeight)

            # line number
            $lineNo = "{0,3}" -f ($row + 1)
            Draw-StringSafe -G $g -Text $lineNo -Font $fontCodeSmall -Brush $brushLineNumber -X 18 -Y ($y + 3)

            # background data cells
            for ($col = 0; $col -lt $Cols; $col++) {
                $x = $codeStartX + ($col * $CellWidth)

                $brush = $brushBit0
                if ($bitIndex -lt $bits.Length -and $bits[$bitIndex] -eq 1) {
                    $brush = $brushBit1
                }

                $g.FillRectangle($brush, $x, $y + 2, $CellWidth, $CellHeight - 2)
                $g.DrawRectangle($penBitBorder, $x, $y + 2, $CellWidth, $CellHeight - 2)

                $bitIndex++
            }

            # overlay fake code text
            $lineText = $fakeLines[$row]
            if ($lineText.StartsWith("//")) {
                Draw-StringSafe -G $g -Text $lineText -Font $fontCode -Brush $brushComment -X ($codeStartX + 6) -Y ($y + 2)
            }
            elseif ($lineText.StartsWith("import") -or $lineText.StartsWith("const") -or $lineText.StartsWith("async") -or $lineText.StartsWith("type") -or $lineText.StartsWith("export")) {
                Draw-StringSafe -G $g -Text $lineText -Font $fontCode -Brush $brushKeyword -X ($codeStartX + 6) -Y ($y + 2)
            }
            elseif ($lineText.Contains('"')) {
                Draw-StringSafe -G $g -Text $lineText -Font $fontCode -Brush $brushString -X ($codeStartX + 6) -Y ($y + 2)
            }
            else {
                Draw-StringSafe -G $g -Text $lineText -Font $fontCode -Brush $brushText -X ($codeStartX + 6) -Y ($y + 2)
            }
        }

        # cursor
        $cursorX = $codeStartX + (32 * $CellWidth) + 6
        $cursorY = $codeStartY + (8 * $CellHeight) + 4
        $g.FillRectangle((New-Object System.Drawing.SolidBrush($cursorColor)), $cursorX, $cursorY, 2, $CellHeight - 6)

        # status bar
        $statusY = $CanvasHeight - 24
        $g.FillRectangle($brushAccent, 0, $statusY, $CanvasWidth, 24)
        Draw-StringSafe -G $g -Text "main  UTF-8  LF  TypeScript  Visual Transport" -Font $fontUi -Brush ([System.Drawing.Brushes]::White) -X 14 -Y ($statusY + 3)
        Draw-StringSafe -G $g -Text ($sha256.Substring(0, 16)) -Font $fontUi -Brush ([System.Drawing.Brushes]::White) -X ($CanvasWidth - 220) -Y ($statusY + 3)

        $bmp.Save($OutPng, [System.Drawing.Imaging.ImageFormat]::Png)
    }
    finally {
        if ($g) { $g.Dispose() }
        if ($bmp) { $bmp.Dispose() }
    }
}

$PartsDir = (Resolve-Path -LiteralPath $PartsDir).Path
Ensure-Dir $OutDir
$OutDir = (Resolve-Path -LiteralPath $OutDir).Path

$parts = Get-ChildItem -LiteralPath $PartsDir -File | Sort-Object Name
if (-not $parts -or $parts.Count -eq 0) {
    throw "PartsDir 下没有找到分片文件"
}

$total = $parts.Count
Write-Host "PartsDir : $PartsDir"
Write-Host "OutDir   : $OutDir"
Write-Host "Count    : $total"

for ($i = 0; $i -lt $parts.Count; $i++) {
    $part = $parts[$i]
    $index = $i + 1
    $outPng = Join-Path $OutDir ($part.BaseName + ".png")

    Write-Host ("[{0}/{1}] Rendering {2}" -f $index, $total, $part.Name)

    Render-PartFrame `
        -PartPath $part.FullName `
        -OutPng $outPng `
        -CanvasWidth $CanvasWidth `
        -CanvasHeight $CanvasHeight `
        -LeftGutterWidth $LeftGutterWidth `
        -TopBarHeight $TopBarHeight `
        -TabBarHeight $TabBarHeight `
        -EditorPadding $EditorPadding `
        -CellWidth $CellWidth `
        -CellHeight $CellHeight `
        -Cols $Cols `
        -Rows $Rows `
        -Index $index `
        -Total $total
}

Write-Host ""
Write-Host "Done."
Write-Host "Frames: $OutDir"